//!javascript

//#=======#======================================#//
//#       #                                      #//
//#  JS   #         K R O S S - F C G I          #//
//#       #                                      #//
//#=======#======================================#//

var VERSION = 'v.0.2.5';
var COPYRIGHT = 'Copyright (c) 2011 Andrey Teleshov <tele-post@mail.ru>';

var o = {
	dist : {
		table : {
			callback : 'op_table_dist',
			sql : 'SELECT d.pair,d.mark,c.type,c.numb,c.port,'+
				'c.name,c.desc,COUNT(conn.id) '+
				'FROM dist AS d, circ AS c '+
				'LEFT OUTER JOIN conn ON conn.p0 = d.pair OR conn.p1 = d.pair '+
				'WHERE d.circ_id = c.id ',    //... + GROUP BY d.pair 
			tbl_body: false,
			data: false,
		},
	},
	conn : {
		table : {
			callback : 'op_table_conn',
			sql : 'SELECT p0,p1,type FROM conn',
			tbl_body: false,
			data: false,
		},
	},
	hist : {
		table : {
			callback : 'op_table_hist',
			sql : 'SELECT dt,act,past,came FROM hist',
			tbl_body: false,
			data: false,
		},
	},
	pair : {
		item : {
			callback : 'op_item',
			sql : 'SELECT id,p0,p1,type FROM conn ',
		},
		more : {
			callback : 'op_item_more',
			sql : 'SELECT d.pair,d.mark,c.type,c.numb,c.port,'+
				'c.name,c.desc,c.id '+
				'FROM dist AS d, circ AS c WHERE d.circ_id = c.id '+
				'AND d.pair IN ',
		},
	},
};

var type_order = [		// option: sel_type
	'PBX_Y','PBX_N','KEY','SLT','CO','ADASE','E&M','C_MISC',
	'C_SS','C_PSTN','C_CH','RR','C_E1','CAB','REC','FREE'
];

var type_cmp = {		// composite types
	'PBX_Y' : 'IN ("KEY","SLT","CO","ADASE","E&M","TERM","MISC")',
	'PBX_N' : 'NOT IN ("KEY","SLT","CO","ADASE","E&M","TERM","MISC")',
	'C_MISC': 'IN ("MISC","TERM","COM","DEV")',
	'C_SS'  : 'IN ("SS","FXO")',
	'C_PSTN': 'IN ("PSTN","FXS")',
	'C_CH'  : 'IN ("CH","EM")',
	'C_E1'  : 'IN ("E1","E1TX","E1RX")',
};

var type_lines = {
	'ADASE' : 4,
	'CH'    : 2,
	'COM'   : 2,
	'DEV'   : 5,
	'E&M'   : 4,
	'EM'    : 2,
	'E1'    : 2,
	'RR'    : 2,
	'TERM'  : 3,
};

var lang = {
	'ADASE' : 'АДАСЭ',
	'C_CH'  : 'канал',
	'C_E1'  : 'E1',
	'C_MISC': 'разное',
	'C_PSTN': 'город',
	'C_SS'  : 'абонент',
	'CAB'   : 'кабель',
	'CH'    : 'канал',
	'COM'   : 'компьютер',
	'DEV'   : 'коробочка',
	//'CO'    :'2-пров.СЛ',
	'E&M'   : 'E&M',
	'EM'    : 'кан-упр',
	'FREE'  : 'свободно',
	'MISC'  : 'разное',
	'PBX_N' : 'кроме станции', 
	'PBX_Y' : 'только станция',
	'REC'   : 'запись',
	'RR'    : 'отбойник',
	'PSTN'  : 'город',
	'SS'    : 'абонент',
	'TERM'  : 'терминал',
	'X'     : 'кроссировка',
	'CON'   : 'соединение',
	'DIS'   : 'разъединение',
	'UPD'   : 'правка',
};

var edit_memo = {
	field: ['numb','name','desc'],
	order: ['edit_numb','edit_name','edit_desc'],
	index: [3,5,6],
	conn_orig: {},
	conn_user: {},
};

var is_mode_new_conn = false;
var note_active = false;
var note_pad = {};
var pages_tbl = ['page_dist','page_conn','page_hist'];
var pages = {};
var selected_column = '';
var selected_pair = '';
var url_tbl = '';

/*--------------------- init ---------------------*/

var ready = false;

function init() {
	var tag,div;
	o.dist.table.tbl_body = parent._tbl.document.getElementById('tbody_dist');
	o.conn.table.tbl_body = parent._tbl.document.getElementById('tbody_conn');
	o.hist.table.tbl_body = parent._tbl.document.getElementById('tbody_hist');

	url_tbl = parent._tbl.location.href;

	for (var i = pages_tbl.length; i--; ) {
		tag = pages_tbl[i];
		div = parent._tbl.document.getElementById(tag);
		div.style.display = 'none';
		pages[tag] = div;
	}
	page_ctl_find_init();

	var note = note_new();
	note_pad[note.id] = note;
	note_active = note;

	ct.session = 'KROSS';
	ct.url = 'kross.fpl';
	ready = true;
	setTimeout(function() { on_switch_tbl('dist1'); },300);
}

/*-------------------- handle --------------------*/
// NOTE: call by another frames

function handle(op,tag,data) {
	if (!ready) return false;
	switch (op) {
		case 'on_switch_tbl'       : on_switch_tbl(tag); break;		//tag
		case 'on_click_tbl_column' : on_click_tbl_column(tag,data); break;	//tag,col_name
		case 'on_click_tbl_pair'   : on_click_tbl_pair(tag); break;		//pair
		case 'on_click_note_pair'  : on_click_note_pair(tag); break;	//pair
		case 'on_click_note_pin'   : on_click_note_pin(); break;		//--
		case 'on_click_note_close' : on_click_note_close(tag); break;	//id
		case 'on_click_disconn'    : on_click_disconn(tag,data); break;	//pair,opposite
		case 'on_click_new_conn'   : on_click_new_conn(); break;		//--
		case 'on_click_new_conn_add'    : on_click_new_conn_add(); break;	 //--
		case 'on_click_new_conn_cancel' : on_click_new_conn_cancel(); break; //--
		case 'on_click_save'       : on_click_save(); break;			//--
		case 'on_press_enter'      : on_press_enter(tag,data); break;	//tag,id_list
		case 'on_about'            : on_about(); break;
	}
	return false;
}

function on_switch_tbl(tag) {
	var where = '';
	switch (tag) {
		case 'dist1' :
			tag = 'dist';			//ugly!
			pages['page_conn'].style.display = 'none';
			pages['page_hist'].style.display = 'none';
			pages['page_dist'].style.display = '';		// show
			where = page_ctl_find_read();
			where += ' GROUP BY d.pair';
			break;
		case 'dist2' :
			tag = 'dist';			//ugly!
			pages['page_conn'].style.display = 'none';
			pages['page_hist'].style.display = 'none';
			pages['page_dist'].style.display = '';		// show
			where = page_ctl_selc_read();
			where += ' GROUP BY d.pair';
			break;
		case 'conn' :
			pages['page_dist'].style.display = 'none';
			pages['page_hist'].style.display = 'none';
			pages['page_conn'].style.display = '';		// show
			break;
		case 'hist' :
			pages['page_dist'].style.display = 'none';
			pages['page_conn'].style.display = 'none';
			pages['page_hist'].style.display = '';		// show
			where = page_ctl_hist_by_pair();
			where += ' ORDER BY dt';
			break;
	}
	get_table(tag,where);
}

function on_click_tbl_pair(pair) {
	tbl_row_highlight(pair);
	if (is_mode_new_conn) {
		set_new_conn_pair(pair);
	} else {
		set_page_edit_pre(pair);
	}
	set_note_wait();
	get_item(pair);
}

/*--------------- query to server ----------------*/

function get_table(tag,where) {
	var m = o[tag].table;
	if (!m) return;
	ct.send({
		op       : 'sql_query',
		tag      : tag,
		callback : m.callback,
		sql      : m.sql + where,
	});
}

function get_item(pair) {
	var m = o['pair'].item;
	if (!m) return;
	set_note_wait();
	var sql = m.sql +
		' WHERE p0 IN("'+ pair +'") OR p1 IN("'+ pair +'")';
	ct.send({
		op       : 'sql_long',
		tag      : pair,
		callback : m.callback,
		sql      : sql,
	});
}

function get_item_more(pair,list) {
	var m = o['pair'].more;
	if (!m) return;
	var sql = m.sql + list;
	ct.send({
		op       : 'sql_query',
		tag      : pair,
		callback : m.callback,
		sql      : sql,
	});
}

function get_check_pair_have(pair,opposite) {
	var sql = 'SELECT pair FROM dist WHERE pair = "'+ opposite +'"';
	ct.send({
		op       : 'sql_atom',
		tag      : pair,
		callback : 'op_check_pair_have',
		sql      : sql,
	});
	//TODO set label: -- wait --
}

function get_fill_find_step_one(circ_id) {
	var sql = 'SELECT d.pair,c.id,c.numb,c.port,c.name,c.desc '+
			'FROM dist AS d, circ AS c '+
			'WHERE d.circ_id = c.id AND c.id = '+ circ_id;
	ct.send({
		op       : 'sql_query',
		tag      : 'none',
		callback : 'op_fill_find_step_two',
		sql      : sql,
	});
}

function put_save_do(tag,sql) {
	ct.send({
		op       : 'sql_do',
		tag      : tag,
		callback : 'op_return_save_do',
		sql      : sql,
	});
}

function put_fill_find(tag,sql) {
	ct.send({
		op       : 'sql_do',
		tag      : tag,
		callback : 'none',
		sql      : sql,
	});
}

/*------------------- callback -------------------*/
// NOTE: call by XHR

function op_table_dist(tag,data) {
	var m = o[tag].table;
	if (!m) return;
	m.data = data;
	on_click_tbl_column(tag,(m.col_name || 'pair'));
}

function op_table_conn(tag,data) {
	var m = o[tag].table;
	if (!m) return;
	m.data = data;
	tbl_fill_conn(m.tbl_body,data);
}

function op_table_hist(tag,data) {
	var m = o[tag].table;
	if (!m) return;
	m.data = data;
	tbl_fill_hist(m.tbl_body,data);
}

function op_item(pair,data) {
	set_note_normal();
	var td = note_active.conn;			// note_conn
	td.innerHTML = fmt_para(data);
	if (!is_mode_new_conn) {
		set_page_edit_conn(pair,data);
	}
	set_note_wait();
	get_item_more(pair,fmt_list(pair,data));
}

function op_item_more(pair,data) {
	set_note_normal();
	var tbody = note_active.dist;		// note_dist
	tbl_fill_note_dist(tbody,data);
	if (!is_mode_new_conn) {
		set_page_edit_dist(pair,data);
	}
}

function op_check_pair_have(pair,data) {
	var opposite = '';
	if (data[0]) {			//good, opposite is have
		if (pair != edit_memo.pair) return;		//oops :(
		opposite = data[0];
		edit_memo.conn_user[opposite] = 1;
		set_area_edit_conn_normal(pair);
		edit_memo.button_save.elem.disabled = false;
	} else {			//bad, opposite is not have
		if (pair == edit_memo.pair) {
			opposite = ' '+ edit_memo.opposite;
		}
		alert("Пара"+ opposite +", кроссировку к которой \n"+
				"вы пытаетесь добавить, не существует.\n"+
				"Добавление отменено.");
	}
}

function op_return_save_do(pair,data) {
	set_note_wait();
	get_item(pair);
}

function op_fill_find_step_two(tag,data) {
	fill_find_step_two(tag,data);
}

/*------------------- sub fmt --------------------*/

function fmt_para(aoa) {
	var arr,t;
	var q = [];
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		t = arr[3] || 'X';
		t = lang[t] || '';
		q.push(arr[1] +' --- '+ arr[2] +' &nbsp; '+ t);
	}
	return q.length ? q.join('<br />') : '-- пусто --';
}

function fmt_list(pair,aoa) {
	var arr,hash,k,q;
	hash = {};
	++hash[pair];
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];			//row [0:id,1:p0,2:p1,3:type]
		++hash[arr[1]];
		++hash[arr[2]];
	}
	q = [];
	for (var k in hash) q.push("'"+ k +"'");
	return '('+ q.join(',') +')';
}

function fmt_pair(s) {
	var re = /[^A-Za-z0-9]/g;
	s = s.replace(re,'');
	s = '0000'+ s.toUpperCase();
	return s.substr(-4);		// XXXX
}

function fmt_dd(s) {
	s = '00'+ s;
	return s.substr(-2);		// XX
}

function fmt_dt(dt) {
	if (!dt) return '';
	var d = new Date(dt * 1000);	//msec
	return d.getFullYear() +'-'+ 
			fmt_dd(d.getMonth()) +'-'+ fmt_dd(d.getDate()) +' '+ 
			fmt_dd(d.getHours()) +':'+ fmt_dd(d.getMinutes());
}

function fmt_find(s) {
	var re;
	s = s.toLowerCase();
	re = /\?/g;  s = s.replace(re,'_');		// [?] joker
	re = /\*/g;  s = s.replace(re,'%');		// [*] wildcard
	return s;
}

/*-------------------- table ---------------------*/

function tbl_fill(tbody,aoa) {
	var arr,tr,td;
	if (!tbody) return;
	while (tbody.rows.length > 0) tbody.deleteRow(0);
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		tr = tbody.insertRow(tbody.rows.length);
		for (var j = 0; j < arr.length; j++) {
			td = tr.insertCell(tr.cells.length);
			td.innerHTML = arr[j];
		}
	}
}

function tbl_fill_dist(tbody,aoa) {
	//row [0:pair,1:mark,2:type,3:numb,4:port,5:name,6:desc,7:n_conn]
	var arr,tr,td,fun,count,type;
	if (!tbody) return;
	while (tbody.rows.length > 0) tbody.deleteRow(0);
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		tr = tbody.insertRow(tbody.rows.length);
		tr.setAttribute('id',arr[0]);

		td = tr.insertCell(tr.cells.length);
		td.innerHTML = arr[7] > 0 ? '&bull;' : '&nbsp;'; //|raquo|diams

		td = tr.insertCell(tr.cells.length);
		fun = "ji('"+ arr[0] +"')";
		td.innerHTML = '<span class="click_me" onclick="'+
				fun + '">'+ arr[0] +'</span>';

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[1];

		if (!count) {
			type = arr[2];
			count = type_lines[type] || 1;

			td = tr.insertCell(tr.cells.length);
			if (count > 1) td.setAttribute('rowspan',count);
			td.setAttribute('align','center');
			td.innerHTML = lang[type] || type;

			td = tr.insertCell(tr.cells.length);
			if (count > 1) td.setAttribute('rowspan',count);
			td.setAttribute('align','center');
			td.innerHTML = arr[3];

			td = tr.insertCell(tr.cells.length);
			if (count > 1) td.setAttribute('rowspan',count);
			td.setAttribute('align','center');
			td.innerHTML = arr[4];

			td = tr.insertCell(tr.cells.length);
			if (count > 1) td.setAttribute('rowspan',count);
			td.innerHTML = arr[5];

			td = tr.insertCell(tr.cells.length);
			if (count > 1) td.setAttribute('rowspan',count);
			td.innerHTML = arr[6];
		}
		if (count) --count;
	}
}

function tbl_fill_conn(tbody,aoa) {
	//row [0:p0,1:p1,2:type]
	var arr,tr,td,fun,count,type;
	if (!tbody) return;
	while (tbody.rows.length > 0) tbody.deleteRow(0);
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		tr = tbody.insertRow(tbody.rows.length);

		td = tr.insertCell(tr.cells.length);
		fun = "js('dist','"+ arr[0] +"')";
		td.innerHTML = '<span class="click_me" onclick="'+ fun +
				'">'+ arr[0] +'</span>';

		td = tr.insertCell(tr.cells.length);
		fun = "js('dist','"+ arr[1] +"')";
		td.innerHTML = '<span class="click_me" onclick="'+ fun +
				'">'+ arr[1] +'</span>';

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[2];
	}
}

function tbl_fill_hist(tbody,aoa) {
	//row [0:dt,1:act,2:past,3:came]
	var arr,tr,td;
	if (!tbody) return;
	while (tbody.rows.length > 0) tbody.deleteRow(0);
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		tr = tbody.insertRow(tbody.rows.length);

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = fmt_dt(arr[0]);

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = lang[arr[1]] || arr[1];

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[2];

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[3];
	}
}

function tbl_fill_note_dist(tbody,aoa) {
	//row [0:pair,1:mark,2:type,3:numb,4:port,5:name,6:desc]
	var arr,tr,td,fun,type;
	if (!tbody) return;
	while (tbody.rows.length > 0) tbody.deleteRow(0);
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		tr = tbody.insertRow(tbody.rows.length);

		td = tr.insertCell(tr.cells.length);
		fun = "ji('"+ arr[0] +"')";
		td.innerHTML = '<span class="click_me" onclick="'+ fun +
				'">'+ arr[0] +'</span>';

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[1];

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		type = arr[2];
		td.innerHTML = lang[type] || type;

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[3];

		td = tr.insertCell(tr.cells.length);
		td.setAttribute('align','center');
		td.innerHTML = arr[4];

		td = tr.insertCell(tr.cells.length);
		td.innerHTML = arr[5];

		td = tr.insertCell(tr.cells.length);
		td.innerHTML = arr[6];
	}
}

/*------------------ highlight -------------------*/

function tbl_col_highlight(name) {
	var tr,td;
	if (selected_column == name) return;
	tbl_col_highlight_sub(selected_column,'norm');
	tbl_col_highlight_sub(name,'hili');
	selected_column = name;
}

function tbl_col_highlight_sub(id,cls) {
	var th;
	if (!id) return;
	th = parent._tbl.document.getElementById('col_'+ id);
	if (!th) return;
	th.setAttribute('class',cls);
}

function tbl_row_highlight(pair) {
	if (selected_pair == pair) return;
	tbl_row_highlight_sub(selected_pair,'#ffffff');
	tbl_row_highlight_sub(pair,'#ffffa0');
	selected_pair = pair;
}

function tbl_row_highlight_sub(id,color) {
	var tr,td;
	if (!id) return;
	tr = parent._tbl.document.getElementById(id);
	if (!tr) return;
	for (var i = 0, max = tr.cells.length; i < max; i += 1) {
		td = tr.cells[i];
		td.setAttribute('bgcolor',color);
	}
}

/*--------------------- sort ---------------------*/

function on_click_tbl_column(tag,col_name) {
	var m = o[tag].table;
	if (!m) return;
	var data = m.data;
	if (!data) return false;
	m.col_name = col_name;
	tbl_col_highlight(col_name);

	switch (col_name) {
		case 'p0'   : data.sort(sort_by_p0);   break;
		case 'p1'   : data.sort(sort_by_p1);   break;
		case 'pair' : data.sort(sort_by_pair); break;
		case 'type' : data.sort(sort_by_type); break;
		case 'num'  : data.sort(sort_by_num);  break;
		case 'port' : data.sort(sort_by_port); break;
		case 'name' : data.sort(sort_by_name); break;
		case 'desc' : data.sort(sort_by_desc); break;
	}
	switch (tag) {
		case 'dist' : tbl_fill_dist(m.tbl_body,data); break;
		case 'conn' : tbl_fill_conn(m.tbl_body,data); break;
	}
	tbl_row_highlight_sub(selected_pair,'#ffffa0');
}

function sort_by_p0 (a,b) {
	if (a[0] < b[0]) return -1;
	if (a[0] > b[0]) return 1;
	return 0;
}
function sort_by_p1 (a,b) {
	if (a[1] < b[1]) return -1;
	if (a[1] > b[1]) return 1;
	return 0;
}
function sort_by_pair (a,b) {
	if (a[0] < b[0]) return -1;
	if (a[0] > b[0]) return 1;
	return 0;
}
function sort_by_type (a,b) {
	if (a[2] < b[2]) return -1;
	if (a[2] > b[2]) return 1;
	return 0;
}
function sort_by_num (a,b) {
	if (a[3] < b[3]) return -1;
	if (a[3] > b[3]) return 1;
	return 0;
}
function sort_by_port (a,b) {
	if (a[4] < b[4]) return -1;
	if (a[4] > b[4]) return 1;
	return 0;
}
function sort_by_name (a,b) {
	if (a[5] < b[5]) return -1;
	if (a[5] > b[5]) return 1;
	return 0;
}
function sort_by_desc (a,b) {
	if (a[6] < b[6]) return -1;
	if (a[6] > b[6]) return 1;
	return 0;
}

/*------------------- note pad -------------------*/

function note_new() {
	var id,td_conn,tbody_dist,span_control,tbody,tr,td;
	id = id_gen(6);
	tbody = parent._vie.document.getElementById('note_pad');
	tr = tbody.insertRow(tbody.rows.length);
	td = tr.insertCell(tr.cells.length);
	td.innerHTML = '<table border="0" width="100%"><tr><td id="note_conn_'+ 
		id +'" align="left"></td><td>&nbsp;&nbsp;&nbsp;</td>'+
		'<td align="right" valign="top"><span id="note_control_'+
		id +'"></span></td></tr></table>'+
		'<table class="main" border="1"><tbody id="note_dist_'+ 
		id +'"></tbody></table>';
					// TODO <!--<img src="load.gif" />-->
	td_conn = parent._vie.document.getElementById('note_conn_'+ id);
	tbody_dist = parent._vie.document.getElementById('note_dist_'+ id);
	span_control = parent._vie.document.getElementById('note_control_'+ id);
				// record: note_frame,note_conn,note_dist,note_control
	return { id:id, frame_tr:tr, frame_td:td, 
			conn:td_conn, dist:tbody_dist, control:span_control };
}

function on_click_note_pair(pair) {
	parent._tbl.location.href = url_tbl +'#'+ pair;
	on_click_tbl_pair(pair);
}

function set_note_normal() {
	var span = note_active.control;		// note_control
	var td = note_active.frame_td; 		// note_frame td
	td.setAttribute('class','note_active');
	var fun = "js('on_click_note_pin')";
	span.innerHTML = '<span class="click_me" onclick="'+ fun +'">приколоть</span>';
}

function set_note_wait() {
	var span = note_active.control;		// note_control
	span.innerHTML = '- ждите -';
}

function on_click_note_pin() {
	var id = note_active.id;			// note_id
	var span = note_active.control;		// note_control
	var td = note_active.frame_td;		// note_cell
	td.setAttribute('class','note_hold');
	var fun = "js('on_click_note_close','"+ id +"')";
	span.innerHTML = '<span class="click_me" onclick="'+ fun +'">закрыть</span>';

	var note = note_new();
	note_pad[note['id']] = note;
	note_active = note;
}

function on_click_note_close(id) {
	var note = note_pad[id];
	var id = note.id;					// note_id
	var tr = note.frame_tr;				// note_frame tr
	var tbody = parent._vie.document.getElementById('note_pad');
	tr.parentNode.removeChild(tr);
	delete note_pad[id]; 
}

/*----------------- ctl page find ----------------*/

function page_ctl_find_init() {
	var doc,sel,offset,type,name;
	doc = parent._ctl.document;

	sel = doc.getElementById('find_col');
	sel.options[0] = new Option('всему','all',false,false);
	sel.options[1] = new Option('паре','pair',false,false);
	sel.options[2] = new Option('номеру','numb',false,false);
	sel.options[3] = new Option('порту','port',false,false);

	sel = doc.getElementById('sel_type');
	sel.options[0] = new Option('-все-','all',false,false);
	offset = sel.options.length;		// list is not empty
	for (var i = 0, max = type_order.length; i < max; i += 1) {
		type = type_order[i];
		name = lang[type] || type;
		sel.options[offset + i] = new Option(name,type,false,false);
	}
	sel = doc.getElementById('sel_conn');
	sel.options[0] = new Option('-все-','all',false,false);
	//sel.options[1] = new Option('подключенные','IS_CONN',false,false);
	//sel.options[2] = new Option('свободные','IS_FREE',false,false);
}

function page_ctl_find_read() {
	var doc,find,s;
	var where = '';
	doc = parent._ctl.document;
	find = doc.getElementById('find').value || '';
	if (!find) return '';

	find = fmt_find(find);				//where like find
	s = get_sel(doc,'find_col');
	switch (find.substring(0,1)) {		//'@X'-pair, '#X'-numb, '/X'-port
		case '@' : s = 'pair'; find = find.substring(1); break;
		case '#' : s = 'numb'; find = find.substring(1); break;
		case '/' : s = 'port'; find = find.substring(1); break;
	}
	switch (s) {
		case 'pair' : where += ' AND d.pair LIKE  "'+ find +'%"'; break;
		case 'numb' : where += ' AND c.numb LIKE  "'+ find +'%"'; break;
		case 'port' : where += ' AND c.port LIKE  "'+ find +'%"'; break;
		default     : where += ' AND c.find LIKE "%'+ find +'%"'; break;
	}
	return where;
}

function page_ctl_selc_read() {
	var doc,s;
	var where = '';
	doc = parent._ctl.document;
	s = get_sel(doc,'sel_type');			//where by type|conn
	if (s) {
		s = type_cmp[s] || '= "'+ s +'"';
		where += ' AND c.type '+ s;
	}
	s = get_sel(doc,'sel_conn');
	switch (s) {
		//case 'IS_CONN' :
		//    where += ' AND ';
		//    break;
		//case 'IS_FREE' :
		//    where += ' AND ';
		//    break;
		default : break;
	}
	return where;
}

function get_sel(doc,id) {
	var s,sel;
	sel = doc.getElementById(id);
	if (sel.selectedIndex === -1) return '';
	s = sel.options[sel.selectedIndex].value || '';
	if (s == 'all') s = '';
	return s;
}

function on_press_enter(tag,data) {
	var doc,arr,t;
	switch (tag) {
		case 'find' : on_switch_tbl('dist1'); break;
		case 'next' :
			doc = parent._ctl.document;
			arr = data.split(',');
			for (var i = 0, max = arr.length; i < max; i += 1) {
				t = doc.getElementById(arr[i]);
				if (t.disabled) continue;
				t.focus();
				break;
			}
			break;
	}
}

/*----------------- ctl page edit ----------------*/

function set_page_edit_pre(pair) {
	var doc,t,key;
	doc = parent._ctl.document;
	doc.getElementById('hist_pair').innerHTML = pair;
	doc.getElementById('edit_pair').innerHTML = pair;
	doc.getElementById('edit_conn').innerHTML = '&nbsp;';
	doc.getElementById('area_new_conn').innerHTML = '&nbsp;';

	for (var j = edit_memo.order.length; j--; ) {
		key = edit_memo.order[j];
		t = doc.getElementById(key);
		t.value = '';
		t.disabled = true;
		edit_memo[key] = { elem: t, orig: '' };
	}
	edit_memo.pair = '';
	edit_memo.circ = '';
	edit_memo.button_save = { elem: doc.getElementById('button_save') };
	edit_memo.button_save.elem.disabled = true;
}

function set_page_edit_dist(pair,aoa) {
	var doc,key,val;
	doc = parent._ctl.document;
	doc.getElementById('edit_pair').innerHTML = pair;
	//row [0:pair,1:mark,2:type,3:numb,4:port,5:name,6:desc,7:id]
	for (var i = aoa.length; i--; ) {
		arr = aoa[i];
		if (pair == arr[0]) {
			for (var j = edit_memo.order.length; j--; ) {
				key = edit_memo.order[j];
				val = arr[edit_memo.index[j]];
				edit_memo[key].elem.value = val;
				edit_memo[key].orig = val;
			}
			edit_memo.pair = pair;
			edit_memo.circ = arr[7];	//vvv-- ugly
			if (arr[4]) {
				edit_memo.edit_numb.elem.disabled = false;
			} else {
				edit_memo.edit_name.elem.disabled = false;
			}
			edit_memo.edit_desc.elem.disabled = false;
			break;
		}
	}
}

function set_page_edit_conn(pair,aoa) {
	var arr,opposite;
	edit_memo.conn_orig = {};
	edit_memo.conn_user = {};
				//row [0:id,1:p0,2:p1,3:type]
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		if (arr[3]) continue;		//krossirovka type only
		if (arr[1] == arr[2]) continue;		//error: with self
		opposite = false;
		if (pair == arr[1]) opposite = arr[2];
		if (pair == arr[2]) opposite = arr[1];
		if (!opposite) continue;

		edit_memo.conn_orig[opposite] = 1;
		edit_memo.conn_user[opposite] = 1;
	}
	set_area_edit_conn_normal(pair);
	set_area_new_conn_normal();
}

function on_click_disconn(pair,opposite) {
	delete edit_memo.conn_user[opposite];
	set_area_edit_conn_normal(pair);
	edit_memo.button_save.elem.disabled = false;
}

function set_area_edit_conn_normal(pair) {
	var opposite,fun,s_conn;
	var arr = [], q = [];
	for (opposite in edit_memo.conn_user) arr.push(opposite);
	arr.sort();
	for (var i = 0, max = arr.length; i < max; i += 1) {
		opposite = arr[i];
		fun = "js('on_click_disconn','"+ pair +"','"+ opposite +"')";
		q.push(pair +' --- '+ opposite +' &nbsp; <span class="click_me" onclick="'+ 
				fun +'">разорвать</span>');
	}
	s_conn = parent._ctl.document.getElementById('edit_conn');
	s_conn.innerHTML = q.length ? q.join('<br />') : '-- нет --';
}

function set_area_new_conn_normal() {
	var span = parent._ctl.document.getElementById('area_new_conn');
	fun = "js('on_click_new_conn')";
	span.innerHTML = '<span class="click_me" onclick="'+ 
				fun +'"> Новая кроссировка </span>';
	is_mode_new_conn = false;
}

function on_click_new_conn() {		//set_area_new_conn_active
	var span,fun_a,fun_c;
	span = parent._ctl.document.getElementById('area_new_conn');
	fun_a = "js('on_click_new_conn_add')";
	fun_c = "js('on_click_new_conn_cancel')";
	span.innerHTML = 'Новая кроссировка:<br />'+
			'<table width="100%" cellspacing="5" border="0"><tr>'+
			'<td align="center">Пара:&nbsp;&nbsp;<input type="text" class="plain" '+
			'id="edit_new_conn" name="edit_new_conn" value="" size="12" '+
			'title="Введите номер пары или кликните по нужной паре"></td></tr>'+
			'<tr><td align="right"><span class="click_me" onclick="'+ 
			fun_c +'"> отменить </span>&nbsp;&nbsp;&nbsp;&nbsp;'+
			'<span class="click_me" onclick="'+ 
			fun_a +'"> добавить </span></td></tr></table>';
	is_mode_new_conn = true;
	setTimeout(function() {
		parent._ctl.document.getElementById('edit_new_conn').focus(); 
	},1);
}

function set_new_conn_pair(pair) {
	parent._ctl.document.getElementById('edit_new_conn').value = pair;
}

function on_click_new_conn_add() {
	var pair = edit_memo.pair;
	var opposite = parent._ctl.document.getElementById('edit_new_conn').value;
	set_area_new_conn_normal();
	if (opposite) {
		opposite = fmt_pair(opposite);
		if (pair == opposite) {
			alert("Пара "+ pair +" не может быть соединена с сама с собой.\n"+
					"Добавление отменено.");
		} else if (edit_memo.conn_user[opposite]) {
			alert("Пара "+ pair +" уже соединена с парой "+ opposite +".\n"+
					"Добавление отменено.");
		} else {
			edit_memo.opposite = opposite;
			get_check_pair_have(pair,opposite);
		}
	}
}

function on_click_new_conn_cancel() {
	set_area_new_conn_normal();
}

function on_click_save() {
	var key,val,pair,opposite,p0,p1;
	var sql = [], q = [];
	pair = edit_memo.pair;
	edit_memo.button_save.elem.disabled = true;		//TODO if success transaction

				//--- dist ---//
	for (var j = edit_memo.order.length; j--; ) {
		key = edit_memo.order[j];
		val = edit_memo[key].elem.value;
		if (val != edit_memo[key].orig) {
			q.push(edit_memo.field[j] +' = "'+ val +'"');
		}
	}
	if (q.length) {
		sql.push('UPDATE circ SET '+ q.join(', ') +' WHERE id = '+
				'(SELECT circ_id FROM dist WHERE pair = "'+ pair +'")');
	}
				//--- conn ---//
	for (opposite in edit_memo.conn_user) {
		if (!edit_memo.conn_orig[opposite]) {
			if (pair < opposite) {
				p0 = pair;  p1 = opposite;
			} else {
				p1 = pair;  p0 = opposite;
			}
			sql.push('INSERT INTO conn (p0,p1) VALUES '+
					'("'+ p0 +'","'+ p1 +'")');
		}
	}
	for (opposite in edit_memo.conn_orig) {
		if (!edit_memo.conn_user[opposite]) {
			if (pair < opposite) {
				p0 = pair;  p1 = opposite;
			} else {
				p1 = pair;  p0 = opposite;
			}
			sql.push('DELETE FROM conn WHERE '+
					'p0 = "'+ p0 +'" AND p1 = "'+ p1 +'"');
		}
	}
	if (sql.length) {
		put_save_do(pair,sql.join('; '));
	}
	setTimeout(function() { get_fill_find_step_one(edit_memo.circ); },1300);
}

function fill_find_step_two(tag,aoa) {
	var arr,sql,id;
	var s = '';
	for (var i = 0, max = aoa.length; i < max; i += 1) {
		arr = aoa[i];
		s += arr[0] +' ';
		id = arr[1];
	}
	if (!id) return;
	arr.shift();  arr.shift();
	s += arr.join(' ');
	s = s.toLowerCase();
	sql = 'UPDATE circ SET find = "'+ s +'" WHERE id = '+ id;
	put_fill_find('none',sql);
}

/*----------------- ctl page hist ----------------*/

function page_ctl_hist_by_pair() {
	var where = '';
	var pair = edit_memo.pair;
	var circ = edit_memo.circ;
	if (pair) where += ' WHERE p0 = "'+ pair +'" OR p1 = "'+ pair +'"';
	if (circ) where += ' OR circ_id = "'+ circ +'"';
	return where;
}

function on_about() {
	alert('КРОСС '+ VERSION +"\n\n"+ COPYRIGHT);
}





//+==============================================+//
//|                                              |//
//|                  TRANSPORT                   |//

var ct = {
	session: '',
	url: '/',
}

ct.send = function(obj) {
	var arr,str,key;
	if (!ct.session) return;

	switch (typeof(obj)) {
		case 'object' : 
			arr = [];
			for (key in obj) arr.push(key +"\x1E"+ obj[key]);
			str = arr.join("\x1E");
			break;
		case 'string' : str = obj; break;
		default : alert('ERROR! OBJ TYPE: '+ typeof(obj)); 
				  return; break;
	}
	ct._send({ 'X-Session': ct.session },str);
}

ct._send = function(head,str) {
	var xhr = ct.newXHR();
	xhr.open('POST',ct.url,true);
	xhr.setRequestHeader('Content-Type','application/octet-stream');
	for (var key in head) {
		xhr.setRequestHeader(key,head[key]);
	}
	xhr.onreadystatechange = function () {
		try {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					eval(xhr.responseText);
				}
			}
		} catch (e) {};
	};
	xhr.send(str ? str +"\n" : null);
}

ct.newXHR = function() {
	try { return new XMLHttpRequest() } catch (e) {};
	try { return new ActiveXObject('Msxml2.XMLHTTP') } catch (e) {};
	try { return new ActiveXObject('Microsoft.XMLHTTP') } catch (e) {};
	return false;
}

//|                  transport                   |//
//+----------------------------------------------+//


function id_gen(max) {
	var base62 = "0123456789"+
		"abcdefghijklmnopqrstuvwxyz"+
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var i,j;
	var s = '';
	if (!max) max = 5;
	for (i = 0; i < max; i += 1) {
		j = Math.floor(Math.random() * 63);
		s += base62.charAt(j);
	}
	return s;
}

/*--------------------- end ----------------------*/

