//!javascript

//#=======#======================================#//
//#       #                                      #//
//#  JS   #        K R O S S - A D M I N         #//
//#       #                                      #//
//#=======#======================================#//

var VERSION = 'v.0.2.5';
var COPYRIGHT = 'Copyright (c) 2011 Andrey Teleshov <tele-post@mail.ru>';

var o = {
	check : {
		callback : 'op_check_pair_between',
		sql : 'SELECT COUNT(*) FROM dist WHERE pair BETWEEN ',   // y AND z 
	},
}

var type_order = [		// option: sel_type
	'KEY','SLT','CO','ADASE','E&M','MISC','TERM','COM','DEV',
	'SS','FXO','PSTN','FXS','CH','EM','RR','E1','E1TX','E1RX',
	'CAB','REC','FREE'
];

var type_mark = {
	ADASE  : ['Rx','Tx','DK','--'],
	'E&M'  : ['Tx','Rx','E','M'],
	CH     : ['Tx','Rx'],
	EM     : ['E','M'],
	E1     : ['Tx','Rx'],
	RR     : ['Lin','Pho'],
	TERM   : ['rxd,txd','rts,cts','dtr,dsr'],
	COM    : ['rxd,txd','GND'],
	DEV    : ['Пр','+-','Пер','Вкл','Выкл'],
};

var lang = {
	'ADASE' : 'АДАСЭ',
	'CAB'   : 'кабель',
	'CH'    : 'канал',
	'COM'   : 'компьютер',
	'DEV'   : 'коробочка',
	//'CO'    :'2-пров.СЛ',
	'E&M'   : 'E&M',
	'EM'    : 'кан-упр',
	'FREE'  : 'свободно',
	'MISC'  : 'разное',
	'REC'   : 'запись',
	'RR'    : 'отбойник',
	'PSTN'  : 'город',
	'SS'    : 'абонент',
	'TERM'  : 'терминал',
};

var valid_ac = ['00','01'];
var button_ok = false;
var job = false;
var ready = false;

/*--------------------- init ---------------------*/

function _init() {
	ct.session = 'KROSS';
	ct.url = 'kross.fpl';
	document.getElementById('header').innerHTML = '<center><h1>КРОСС</h1></center>';
	document.getElementById('main').innerHTML = 
		'<form onsubmit="return false;"><center><table class="frame" border="0">'+
		'<tr><td>Код доступа:</td><td><input type="text" class="plain" '+
		'id="input_ac" name="input_ac" value="" size="12" '+
		'onkeypress="on_key_press(event);" '+
		'onchange="on_change_ac();"></td><td><input id="button_ok" type="button" '+
		'value=" OK " onclick="on_press_enter();">'+
		'</td></tr></table></center></form>';
	setTimeout(function() {
		document.getElementById('input_ac').focus(); 
		button_ok = document.getElementById('button_ok');
		button_ok.disabled = true;
	},1);
	ready = true;
}

function _init_main() {
	document.getElementById('main').innerHTML = 
		'<table width="100%" border="0"><tr>'+
		  '<td id="td_ctrl" width="40%" valign="top"></td>'+
		  '<td id="td_info" width="60%" valign="top"><ul></td>'+
		'</tr></table>';
	setTimeout(function() { _init_ctrl() },100);
}

function _init_ctrl() {
	document.getElementById('td_ctrl').innerHTML = 
		//<!-- PAGE - ADD -->
'<div class="head"><span class="click_me" '+
  'onclick="toggle(\'page_add\');"> Добавление </span></div>'+
'<div id="page_add" class="page"><center><form onsubmit="return false;">'+
'<p>Добавить пары</p>'+
'<table class="form" border="0">'+
  '<tr><td align="right">от:</td>'+
    '<td><input class="plain" id="pair_a_fr" name="pair_a_fr" size="16" value="" '+
	  'onkeypress="on_key_press(\'pair_a_fr\',\'\',event);" '+ 
	  'title="Начало диапазона" placeholder="номер пары"></td></tr>'+
  '<tr><td align="right">до:</td>'+
    '<td><input class="plain" id="pair_a_to" name="pair_a_to" size="16" value="" '+
	  'onkeypress="on_key_press(\'pair_a_to\',\'\',event);" '+ 
	  'title="Конец диапазона" placeholder="номер пары"></td></tr>'+
  '<tr><td align="right">тип:</td>'+
    '<td><select id="sel_type" name="sel_type"></select></td></tr>'+
  '<tr><td> &nbsp; </td>'+
  '<td align="right"><input id="button_add" type="button" value=" Добавить " '+
      'onclick="js(\'on_add\',\'add\');"></td>'+
'</table></form></center></div>'+
		//<!-- PAGE - DEL -->
'<div class="head"><span class="click_me" '+
  'onclick="toggle(\'page_del\');"> Удаление </span></div>'+
'<div id="page_del" class="page"><center><form onsubmit="return false;">'+
'<p>Удалить пары</p>'+
'<table class="form" border="0">'+
  '<tr><td align="right">от:</td>'+
    '<td><input class="plain" id="pair_d_fr" name="pair_d_fr" size="16" value="" '+
	  'onkeypress="on_key_press(\'pair_d_fr\',\'\',event);" '+ 
	  'title="Начало диапазона" placeholder="номер пары"></td></tr>'+
  '<tr><td align="right">до:</td>'+
    '<td><input class="plain" id="pair_d_to" name="pair_d_to" size="16" value="" '+
	  'onkeypress="on_key_press(\'pair_d_to\',\'\',event);" '+ 
	  'title="Конец диапазона" placeholder="номер пары"></td></tr>'+
  '<tr><td> &nbsp; </td>'+
  '<td align="right"><input id="button_del" type="button" value=" Удалить " '+
			'onclick="js(\'on_del\',\'del\');"></td>'+
'</table></form></center></div>'+
		//<!-- PAGE - OTHER -->
'<div class="head"><span class="click_me" '+
  'onclick="toggle(\'page_oth\');"> Ещё... </span></div>'+
'<div id="page_oth" class="page"><center><form onsubmit="return false;"><p>'+
'<input id="button_fifi" type="button" value=" Обновить данные для поиска " '+
			'onclick="js(\'on_fifi\',\'fifi\');"><br>&nbsp;<br>'+
'<input id="button_purge" type="button" value=" Чистить базу " '+
			'onclick="js(\'on_purge\',\'purge\');"><br>&nbsp;<br>'+
'</p></form></center></div>';

	setTimeout(function() {
		document.getElementById('page_add').style.display = 'none';
		document.getElementById('page_del').style.display = 'none';
		document.getElementById('page_oth').style.display = 'none';
	},1);
	setTimeout(function() { _init_sel_type() },100);
}

function _init_sel_type() {
	sel = document.getElementById('sel_type');
	sel.options[0] = new Option('','',false,false);
	offset = sel.options.length;		// list is not empty
	for (var i = 0, max = type_order.length; i < max; i += 1) {
		type = type_order[i];
		name = lang[type] || type;
		sel.options[offset + i] = new Option(name,type,false,false);
	}
}

/*--------------------- work ---------------------*/

function _ins_circ() {
	job.i = job.beg;
	job.j = 0;
	setTimeout(function() { _loop_for_circ() },100);
}

function _loop_for_circ() {
	if (job.i > job.end) {
		_info_cut();
		_info('Успешно добавлено '+ job.nn +' пар.');
		return;		// exit loop
	}
	_ins_info(true);
	cmd_ins_circ(job.typ);
}

function _loop_for_dist() {
	_ins_info(false);
	cmd_ins_dist(job.i,job.marks[job.j],job.id);
}

function _ins_info(is_circ) {
	if (is_circ) { ++job.nc;  job.nd = 0; }
	_info_cut();
	_info('<!--TAIL-->Добавляется "'+ job.i +
			'" пара ('+ job.nc +','+ job.nd +').');
	++job.nd;
}

function _del_dist() {
	cmd_del_dist(job.beg,job.end);
}

/*--------------- query to server ----------------*/

function cmd_check_pair_between(tag,beg,end) {
	var el = o['check'];
	var sql = el.sql +' "'+ beg +'" AND "'+ end +'"';
	ct.send({
		op       : 'sql_atom',
		tag      : tag,
		callback : el.callback,
		sql      : sql,
	});
}

function cmd_ins_circ(type) {
	var tag = 'none';
	var sql = 'INSERT INTO circ (type) VALUES ("'+ type +'")';
	ct.send({
		op       : 'sql_do',
		tag      : tag,
		callback : 'op_ins_circ',
		sql      : sql,
		get_id   : '1',
	});
}

function cmd_ins_dist(pair,mark,id_c) {
	var tag = 'none';
	var sql = 'INSERT INTO dist (pair,mark,circ_id) '+
			'VALUES ("'+ pair +'","'+ mark +'",'+ id_c +')';
	ct.send({
		op       : 'sql_do',
		tag      : tag,
		callback : 'op_ins_dist',
		sql      : sql,
	});
}

function cmd_del_dist(beg,end) {
	var tag = 'none';
	var sql = 'DELETE FROM dist WHERE pair BETWEEN '+
				'"'+ beg +'" AND "'+ end +'"';
	ct.send({
		op       : 'sql_do',
		tag      : tag,
		callback : 'op_del_dist',
		sql      : sql,
	});
}

/*------------------- callback -------------------*/
// NOTE: call by XHR

function op_check_pair_between(tag,data) {
	var fun_n = "js('on_button_no','"+ tag +"')";
	var fun_y = "js('on_button_yes','"+ tag +"')";
	var n = data[0] || 0;

	switch (tag) {
		case 'add' : 
			if (n > 0) {
				_info('Добавление невозможно. Диапазон занят: '+ n +' пар.');
			} else {
				_info('Диапазон свободен.');
				_info('<!--TAIL-->Вы уверены? &nbsp; '+
					'<input id="button_no" type="button" value=" Нет " '+
					'onclick="'+ fun_n +'">&nbsp;'+
					'<input id="button_yes" type="button" value=" Да " '+
					'onclick="'+ fun_y +'">');
			}
			break;

		case 'del' :
			if (n > 0) {
				_info('В диапазоне имеется и будет удалено '+ n +' пар.');
				_info('<!--TAIL-->Вы уверены? &nbsp; '+
					'<input id="button_no" type="button" value=" Нет " '+
					'onclick="'+ fun_n +'">&nbsp;'+
					'<input id="button_yes" type="button" value=" Да " '+
					'onclick="'+ fun_y +'">');
			} else {
				_info('Стоп. В этом диапазоне нечего удалять.');
			}
			break;

		default : alert('ERROR! op_check_pair_between: unknown tag: '+ tag); 
				  return; break;
	}
}

function op_ins_circ(tag,data) {
	if (!data) return;
	if (typeof(data) != 'object') return;
	var res = data[0];
	if (res != 'OK') return;
	var id = data[2];
	if (!id) return;

	job.id = id;
	setTimeout(function() { _loop_for_dist() },100);
}

function op_ins_dist(tag,data) {
	if (!data) return;
	if (typeof(data) != 'object') return;
	var res = data[0];
	if (res != 'OK') return;

	++job.i;  ++job.j;  ++job.nn;

	if (job.j >= job.marks.length) {
		job.j = 0;
		setTimeout(function() { _loop_for_circ() },100);
	} else {
		setTimeout(function() { _loop_for_dist() },100);
	}
}

function op_del_dist(tag,data) {
	if (!data) return;
	if (typeof(data) != 'object') return;
	var res = data[0];
	if (res != 'OK') return;
	var res = data[1];
	if (!res) return;

	_info('Успешно удалено '+ res +' пар.');
}

/*-------------------- handle --------------------*/
// NOTE: call by HTML

function on_load() { _init() }

function js(op,tag,data) { handle(op,tag,data) }

function handle(op,tag,data) {
	if (!ready) return false;
	switch (op) {
		case 'on_add'         : on_add(tag); break;		//tag
		case 'on_del'         : on_del(tag); break;		//tag
		case 'on_button_yes'  : on_button_yes(tag); break;
		case 'on_button_no'   : on_button_no(tag); break;
	}
	return false;
}

function on_add(tag) {
	var beg,end,typ,marks,tot,ss;
	_info_clear();
	_info('Начало добавления.');
	beg = document.getElementById('pair_a_fr').value;
	end = document.getElementById('pair_a_to').value;
	typ = get_sel('sel_type');

	if (!beg) {
		_info('Стоп. Введите пару начала диапазона.');
		return;
	}
	if (!end) {
		_info('Стоп. Введите пару конца диапазона.');
		return;
	}
	beg = fmt_pair(beg);
	end = fmt_pair(end);

	if (!(beg < end)) {
		_info('Стоп. Начало диапазона должно быть меньше конца диапазона.');
		return;
	}
	if (!typ) {
		_info('Стоп. Выберите тип линий.');
		return;
	}
	marks = type_mark[typ] || [''];
	tot = end - beg;
	ss = [];
	if (tot) {
		++tot;
		ss.push(', всего ');
		if (marks.length > 1) {
			if (tot % marks.length) {		//mod
				_info('Стоп. Некорректно. Количество пар ('+ tot +
						') должно быть кратно числу пар в линии "'+ typ +
						'" ('+ marks.length +').');
				return;
			}
			ss.push((tot / marks.length) +' линий, ');
		}
		ss.push(tot +' пар');
	}
	_info('Добавление пар от "'+ beg +'" до "'+ end +
			'", тип линии "'+ typ +'"'+ ss.join('') +'.');

	job = { beg:beg, end:end, typ:typ, marks:marks, 
			i:0, j:0, nn:0, nc:0, nd:0, id:false };

	cmd_check_pair_between('add',beg,end);
}

function on_del(tag) {
	var beg,end,typ,tot;
	_info_clear();
	_info('Начало удаления.');
	beg = document.getElementById('pair_d_fr').value;
	end = document.getElementById('pair_d_to').value;

	if (!beg) {
		_info('Стоп. Введите пару начала диапазона.');
		return;
	}
	if (!end) {
		_info('Стоп. Введите пару конца диапазона.');
		return;
	}
	beg = fmt_pair(beg);
	end = fmt_pair(end);

	if (!(beg < end)) {
		_info('Стоп. Начало диапазона должно быть меньше конца диапазона.');
		return;
	}
	tot = end - beg;
	tot = (tot) ? ' ('+ (++tot) +' пар)' : '';
	_info('Удаление пар от "'+ beg +'" до "'+ end + '" включительно' + tot +'.');

	job = { beg:beg, end:end };

	cmd_check_pair_between('del',beg,end);
}

function on_button_yes(tag) {
	_info_cut();
	_info('Операция подтверждена.');

	switch (tag) {
		case 'add' : _ins_circ(); break;
		case 'del' : _del_dist(); break;
		default : alert('ERROR! on_button_yes: unknown tag: '+ tag); 
				  return; break;
	}
}

function on_button_no(tag) {
	_info_cut();
	_info('Стоп. Операция отменена.');
}

/*---------------- another handle ----------------*/

function on_change_ac() { if (button_ok) button_ok.disabled = false }

function on_key_press(ev) {
	ev = (ev) ? ev : event;
	var c = (ev.charCode) ? ev.charCode : ((ev.which) ? ev.which : ev.keyCode);
	if (c != 13) return true;
	on_press_enter();
	return true;
}

function on_press_enter() {
	var ac = document.getElementById('input_ac').value;
	var footer = document.getElementById('footer');
	if (ac) {
		for (var i = valid_ac.length; i--;) {
			if (ac == valid_ac[i]) {
				_auth_info('');
				setTimeout(function() { _init_main() },300);
				return true;		//-->
			}
		}
		_auth_info('Код доступа не подходит.');
	} else {
		_auth_info('Введите код доступа.');
	}
}

/*--------------------- sub ----------------------*/

function _info(str) {
	document.getElementById('td_info').innerHTML += '<li>'+ str;
}

function _info_clear() {
	document.getElementById('td_info').innerHTML = '<ul>';
}

function _info_cut() {
	var re = /<li><!--TAIL-->.*$/g;
	var el = document.getElementById('td_info');
	var s = el.innerHTML;
	s = s.replace(re,'');
	el.innerHTML = s;
}

function _auth_info(str) {
	document.getElementById('footer').innerHTML = '<p>'+ str +'</p>';
}

function get_sel(id) {
	var s,sel;
	sel = document.getElementById(id);
	if (sel.selectedIndex === -1) return '';
	s = sel.options[sel.selectedIndex].value || '';
	if (s == 'all') s = '';
	return s;
}

//function _debug_obj(o,str) {
//    var s,key;
//    var arr = [];
//    for (key in o) arr.push(key +'='+ o[key]);
//    s = arr.join('; ');
//    _debug(str +' ['+ s +']');
//}
//
//function _debug(str) {
//    var now = new Date();
//    document.getElementById('debug').innerHTML += 
//            '<li>'+ now.toLocaleTimeString() +' -- '+ str;
//}

function toggle(id) {
	var div = document.getElementById(id);
	div.style.display = div.style.display == 'none' ? '' : 'none';
}

function fmt_pair(s) {
	var re = /[^A-Za-z0-9]/g;
	s = s.replace(re,'');
	s = '0000'+ s.toUpperCase();
	return s.substr(-4);		// XXXX
}

function on_about() {
	alert('Kross-Admin '+ VERSION +"\n\n"+ COPYRIGHT);
}





//+==============================================+//
//|                                              |//
//|                  TRANSPORT                   |//

var ct = {
	session: '',
	url: '/',
}

ct.send = function(obj) {
	var arr,str,key;
	if (!ct.session) return;

	switch (typeof(obj)) {
		case 'object' : 
			arr = [];
			for (key in obj) arr.push(key +"\x1E"+ obj[key]);
			str = arr.join("\x1E");
			break;
		case 'string' : str = obj; break;
		default : alert('ERROR! OBJ TYPE: '+ typeof(obj)); 
				  return; break;
	}
	ct._send({ 'X-Session': ct.session },str);
}

ct._send = function(head,str) {
	var xhr = ct.newXHR();
	xhr.open('POST',ct.url,true);
	xhr.setRequestHeader('Content-Type','application/octet-stream');
	for (var key in head) {
		xhr.setRequestHeader(key,head[key]);
	}
	xhr.onreadystatechange = function () {
		try {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					eval(xhr.responseText);
				}
			}
		} catch (e) {};
	};
	xhr.send(str ? str +"\n" : null);
}

ct.newXHR = function() {
	try { return new XMLHttpRequest() } catch (e) {};
	try { return new ActiveXObject('Msxml2.XMLHTTP') } catch (e) {};
	try { return new ActiveXObject('Microsoft.XMLHTTP') } catch (e) {};
	return false;
}

//|                  transport                   |//
//+----------------------------------------------+//


/*--------------------- end ----------------------*/

