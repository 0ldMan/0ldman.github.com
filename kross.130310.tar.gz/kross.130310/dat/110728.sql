
CREATE TRIGGER d_d_circ 
AFTER DELETE ON circ FOR EACH ROW 
BEGIN
  UPDATE dist SET circ_id = 0, mark = '', ab = 0 
    WHERE circ_id = OLD.id;
END;

CREATE TRIGGER c_u_dist 
AFTER UPDATE OF circ_id ON dist FOR EACH ROW
WHEN NOT OLD.circ_id = 0
BEGIN
  DELETE FROM circ WHERE id = OLD.circ_id;
END;

CREATE TRIGGER c_d_dist 
AFTER DELETE ON dist FOR EACH ROW 
BEGIN
  DELETE FROM circ WHERE id = OLD.circ_id;
  DELETE FROM conn WHERE p0 = OLD.pair OR p1 = OLD.pair;
END;

