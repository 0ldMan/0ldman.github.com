
DROP TRIGGER IF EXISTS h_u_circ;

CREATE TRIGGER h_u_circ AFTER UPDATE OF numb, name, desc ON circ FOR EACH ROW BEGIN INSERT INTO hist (dt, act, circ_id, past, came) VALUES (strftime('%s','now'), 'UPD', old.id, old.numb ||'|'|| old.name ||'|'|| old.desc, new.numb ||'|'|| new.name ||'|'|| new.desc); END;
