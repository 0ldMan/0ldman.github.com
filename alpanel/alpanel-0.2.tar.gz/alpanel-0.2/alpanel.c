#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <dirent.h>
#include <locale.h>
#include "gui.h"
#include "config-parser.h"
#include "xdg.h"
#include "widget-utils.h"
#include "builtin-widgets.h"
#include "args.h"


/* options */
static int show_usage;
static int show_version;
static int show_list;
static const char *config_override;
static const char *theme_override;

#define ALPANEL_VERSION_STR "ALPanel version 0.2\n"
#define ALPANEL_USAGE \
"usage: alpanel [-h | --help] [--version] [--usage] [--list] \n" \
"                [--config=<config>] [--theme=<theme>]\n"

static const char *alpanel_version_str = ALPANEL_VERSION_STR ALPANEL_USAGE;

/* conf and theme */
static struct panel p;
static struct config_format_tree g_conf;
static struct config_format_tree g_theme;

#define ALPANEL_CONFIG_FILE "alpanel/alpanel.conf"


char *get_HOME_DIR()
{
	char *home = getenv("HOME");
	ENSURE(home != 0, "You must have HOME environment variable set");
	return home;
}

/**************************************************************************
  Configure loading
**************************************************************************/

static int try_load_conf(const char *configfile)
{
	char buf[4096];
	if (configfile)
		return load_config_format_tree(&g_conf, configfile);

	/* scan XDG dirs */
	size_t config_dirs_len;
	char **config_dirs = get_XDG_CONFIG_DIRS(&config_dirs_len);
	int found = 0;
	size_t i;

	for (i = 0; i < config_dirs_len; ++i) {
		snprintf(buf, sizeof(buf), "%s/" ALPANEL_CONFIG_FILE,
			 config_dirs[i]);
		buf[sizeof(buf)-1] = '\0';
		if (is_file_exists(buf)) {
			found = 1;
			break;
		}
	}
	free_XDG(config_dirs);

	if (!found)
		return -1;

	if (0 != load_config_format_tree(&g_conf, buf))
		return -1;

	return 0;
}

static int try_load_theme(const char *name)
{
	char buf[4096];
	/* try to load it in-place */
	snprintf(buf, sizeof(buf), "%s/theme", name);
	if (is_file_exists(buf) && 0 == load_config_format_tree(&g_theme, buf))
		return 0;

	/* try to load it in ~/.themes */
	snprintf(buf, sizeof(buf), "%s/.themes/%s/alpanel/theme", 
			get_HOME_DIR(), name);
	if (is_file_exists(buf) && 0 == load_config_format_tree(&g_theme, buf))
		return 0;

	/* scan XDG dirs */
	size_t data_dirs_len;
	char **data_dirs = get_XDG_DATA_DIRS(&data_dirs_len);
	int found = 0;
	size_t i;

	for (i = 0; i < data_dirs_len; ++i) {
		snprintf(buf, sizeof(buf), "%s/alpanel/themes/%s/theme",
			 data_dirs[i], name);
		buf[sizeof(buf)-1] = '\0';
		if (is_file_exists(buf)) {
			found = 1;
			break;
		}
	}
	free_XDG(data_dirs);

	if (!found)
		return -1;

	if (0 != load_config_format_tree(&g_theme, buf))
		return -1;

	return 0;
}

static int load_conf()
{
	const char *name;

	if (try_load_conf(config_override) < 0)
			return -1;

	name = theme_override ? theme_override : 
		find_config_format_entry_value(&g_conf.root, "theme");

	if (name) {
		if (try_load_theme(name) >= 0)
			return 0;

		XWARNING("Failed to load theme \"%s\", trying default \"native\"",
				name);
	} else { 
		XWARNING("Missing theme parameter, trying default \"native\"");
	}
	return try_load_theme("native");
}

void free_conf()
{
	if (g_theme.buf)
		free_config_format_tree(&g_theme);
	clean_static_buf();
	if (g_conf.buf)
		free_config_format_tree(&g_conf);
}

/**************************************************************************
  Listing themes
**************************************************************************/

static void list_theme(const char *themefile, const char *shortname)
{
	if (!is_file_exists(themefile))
		return;

	struct config_format_tree tree;
	if (0 != load_config_format_tree(&tree, themefile))
		return;

	const char *longname = 0;
	const char *author = 0;
	struct config_format_entry *e = find_config_format_entry(&tree.root,
								 "theme");
	if (e) {
		longname = find_config_format_entry_value(e, "name");
		author = find_config_format_entry_value(e, "author");
	}

	printf(" * %s", shortname);
	if (longname || author) {
		printf(" (");
		if (longname) {
			printf("name: %s", longname);
			if (author)
				printf(", ");
		}
		if (author)
			printf("author: %s", author);
		printf(")");
	}
	printf("\n");
	free_config_format_tree(&tree);
}

static void list_themes_in_dir(DIR *d, const char *dirpath)
{
	char buf[4096];
	struct dirent *de;
	int len;

	while ((de = readdir(d)) != 0) {
		len = strlen(de->d_name);
		switch (len) {
			/* skip current dir and parent dir */
		case 1:
			if (de->d_name[0] == '.')
				continue;
		case 2:
			if (de->d_name[0] == '.' && de->d_name[1] == '.')
				continue;
		default:
			break;
		}
		snprintf(buf, sizeof(buf), "%s/%s/theme", dirpath, de->d_name);
		list_theme(buf, de->d_name);
	}
}

static void list_themes()
{
	char buf[4096];
	size_t data_dirs_len;
	char **data_dirs = get_XDG_DATA_DIRS(&data_dirs_len);
	DIR *d;

	size_t i;
	for (i = 0; i < data_dirs_len; ++i) {
		snprintf(buf, sizeof(buf), "%s/alpanel/themes", data_dirs[i]);
		buf[sizeof(buf)-1] = '\0';

		printf("listing themes in \"%s\":\n", buf);
		d = opendir(buf);
		if (d) {
			list_themes_in_dir(d, buf);
			closedir(d);
		} else {
			printf(" - none\n");
		}
	}
}

/**************************************************************************
  Listing ~/.themes
**************************************************************************/

static void list_dot_themes_in_dir(DIR *d, const char *dirpath)
{
	char buf[4096];
	struct dirent *de;
	int len;

	while ((de = readdir(d)) != 0) {
		len = strlen(de->d_name);
		switch (len) {
			/* skip current dir and parent dir */
		case 1:
			if (de->d_name[0] == '.')
				continue;
		case 2:
			if (de->d_name[0] == '.' && de->d_name[1] == '.')
				continue;
		default:
			break;
		}
		snprintf(buf, sizeof(buf), "%s/%s/alpanel/theme", dirpath, de->d_name);
		list_theme(buf, de->d_name);
	}
}

static void list_dot_themes()
{
	char buf[4096];
	DIR *d;

	sprintf(buf, "%s/.themes", get_HOME_DIR());
	if (!is_file_exists(buf))
		return;

	d = opendir(buf);
	if (d) {
		printf("listing themes in \"%s\":\n", buf);
		list_dot_themes_in_dir(d, buf);
		closedir(d);
	}
}

/**************************************************************************
  Main
**************************************************************************/

static int get_monitor()
{
	return parse_int("monitor", &g_conf.root, 0);
}

static gboolean reload_config_event(gpointer data)
{
	return 0;
}

static void sigusr1_handler(int xxx)
{
	g_idle_add(reload_config_event, 0);
}

static void sigusr2_handler(int xxx)
{
	g_idle_add(reload_config_event, 0);
}

static void sigint_handler(int xxx)
{
	XWARNING("sigint signal received, stopping main loop...");
	g_main_loop_quit(p.loop);
}

static void sigterm_handler(int xxx)
{
	XWARNING("sigterm signal received, stopping main loop...");
	g_main_loop_quit(p.loop);
}

static void mysignal(int sig, void (*handler)(int))
{
	struct sigaction sa;
	sa.sa_handler = handler;
	sa.sa_flags = 0;
	sigaction(sig, &sa, 0);
}

static void parse_alpanel_args(int argc, char **argv)
{
	struct argument args[] = {
		ARG_BOOLEAN("usage", &show_usage, "show usage reminder", 0),
		ARG_BOOLEAN("version", &show_version, "print alpanel version", 0),
		ARG_BOOLEAN("list", &show_list, "list available themes", 0),
		ARG_STRING("config", &config_override, "use custom configuration file", 0),
		ARG_STRING("theme", &theme_override, "override config theme parameter", 0),
		ARG_END
	};
	parse_args(args, argc, argv, alpanel_version_str);

	if (show_usage) {
		printf(ALPANEL_USAGE);
		exit(0);
	}
	if (show_version) {
		printf(ALPANEL_VERSION_STR);
		exit(0);
	}
	if (show_list) {
		list_dot_themes();
		list_themes();
		exit(0);
	}
}

int main(int argc, char **argv)
{
	setlocale(LC_TIME, "");
	g_thread_init(0);
	if (!g_thread_supported())
		XDIE("ALPanel requires glib with thread support enabled");
	parse_alpanel_args(argc, argv);
	if (load_conf() < 0)
		XDIE("Failed to load configure");
	clean_image_cache(0);

	XWARNING("-- Loaded configure \"%s\"", g_conf.dir);
	XWARNING("-- Loaded theme \"%s\"", g_theme.dir);

	init_panel(&p, &g_conf, &g_theme, get_monitor());

	mysignal(SIGINT, sigint_handler);
	mysignal(SIGTERM, sigterm_handler);
	mysignal(SIGUSR1, sigusr1_handler);
	mysignal(SIGUSR2, sigusr2_handler);

	panel_main_loop(&p);

	free_panel(&p);
	free_conf();
	clean_image_cache(1);
	xmemstat(0, 0, 1);
	return EXIT_SUCCESS;
}
