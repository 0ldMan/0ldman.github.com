#include <time.h>
#include "builtin-widgets.h"

static int create_widget_private(struct widget *w, struct config_format_entry *ce,
		struct config_format_tree *ctree, struct config_format_tree *ttree);
static void destroy_widget_private(struct widget *w);
static void draw(struct widget *w);
static void clock_tick(struct widget *w);
static void button_click(struct widget *w, XButtonEvent *e);
static void mouse_motion(struct widget *w, XMotionEvent *e);
static void mouse_leave(struct widget *w);
static void reconfigure(struct widget *w);

struct widget_interface clock_interface = {
	.theme_name		= "clock",
	.size_type		= WIDGET_SIZE_CONSTANT,
	.create_widget_private	= create_widget_private,
	.destroy_widget_private = destroy_widget_private,
	.draw			= draw,
	.clock_tick		= clock_tick,
	.button_click		= button_click,
	.mouse_motion		= mouse_motion,
	.mouse_leave		= mouse_leave,
	.reconfigure		= reconfigure
};

/**************************************************************************
  Clock theme
**************************************************************************/

static int parse_clock_state(struct clock_state *cs, const char *name,
		struct config_format_entry *e, struct config_format_tree *tree,
		int required)
{
	struct config_format_entry *ee = find_config_format_entry(e, name);
	if (!ee) {
		if (required)
			required_entry_not_found(e, name);
		cs->exists = 0;
		return -1;
	}

	if (parse_triple_image(&cs->background, ee, tree, 1))
		return -1;

	parse_text_info_named(&cs->font, "font", ee, 0);

	cs->exists = 1;
	return 0;
}

static void free_clock_state(struct clock_state *cs)
{
	if (cs->exists) {
		free_triple_image(&cs->background);
		free_text_info(&cs->font);
	}
}

static int parse_clock_theme(struct clock_theme *ct,
		struct config_format_entry *ce, 
		struct config_format_tree *ctree, struct config_format_tree *ttree)
{
	struct config_format_entry *te = find_config_format_entry(&ttree->root,
			"clock");
	if (!te) {
		required_entry_not_found(&ttree->root, "clock");
		return -1;
	}

	if (parse_clock_state(&ct->states[BUTTON_STATE_IDLE], "idle", te, ttree, 1))
		goto parse_clock_state_error_idle;

	parse_clock_state(&ct->states[BUTTON_STATE_IDLE_HIGHLIGHT],
			     "idle_highlight", te, ttree, 0);
	return 0;

parse_clock_state_error_idle:
	return -1;
}

static void free_clock_theme(struct clock_theme *ct)
{
	unsigned int i;
	for (i = 0; i < 4; ++i)
		free_clock_state(&ct->states[i]);
}

/**************************************************************************
  Clock interface
**************************************************************************/

static void fill_buftime(char *buf, size_t size, struct clock_widget *cw)
{
	time_t current_time;
	current_time = time(0);
	strftime(buf, size, cw->time_format, localtime(&current_time));
}

static int get_clock_width(struct widget *w, const char *bufover)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;
	struct clock_state *cs = &cw->theme.states[BUTTON_STATE_IDLE];
	int text_width = 0;
	int pics_width = 0;

	char buftime[128];
	if (!bufover) {
		fill_buftime(buftime, sizeof(buftime), cw);
		bufover = buftime;
	}
	text_extents(w->panel->layout, cs->font.pfd,
		     bufover, &text_width, 0);

	if (cs->background.center) {
		pics_width += image_width(cs->background.left);
		pics_width += image_width(cs->background.right);
	}
	return text_width + pics_width;
}

static int create_widget_private(struct widget *w, struct config_format_entry *ce,
		struct config_format_tree *ctree, struct config_format_tree *ttree)
{
	struct clock_widget *cw = xmallocz(sizeof(struct clock_widget));
	if (parse_clock_theme(&cw->theme, ce, ctree, ttree)) {
		xfree(cw);
		XWARNING("Failed to parse clock theme");
		return -1;
	}

	cw->time_format = parse_string("time_format", ce, "%H:%M:%S");
	cw->clock_prog = parse_string_or_null("exec", ce);
	cw->mouse_button = parse_int("mouse_button", ce, 1);

	w->private = cw;
	w->width = get_clock_width(w, 0);
	cw->highlighted = -1;
	return 0;
}

static void destroy_widget_private(struct widget *w)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;
	free_clock_theme(&cw->theme);
	xfree(cw->time_format);
	if (cw->clock_prog)
		xfree(cw->clock_prog);
	xfree(cw);
}

static void draw(struct widget *w)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;
	struct clock_state *cs = &cw->theme.states[BUTTON_STATE_IDLE];
	struct clock_state *cur = cs;

	if (cw->highlighted != -1 && cw->clock_prog &&
			cw->theme.states[BUTTON_STATE_IDLE_HIGHLIGHT].exists)
		cur = &cw->theme.states[BUTTON_STATE_IDLE_HIGHLIGHT];

	/* time */
	char buftime[128];
	fill_buftime(buftime, sizeof(buftime), cw);

	/* drawing */
	cairo_t *cr = w->panel->cr;
	int x = w->x;

	int leftw = 0;
	int rightw = 0;
	int centerw = w->width;

	/* draw background only if the center image is here */
	if (cs->background.center) {
		leftw += image_width(cs->background.left);
		rightw += image_width(cs->background.right);
		centerw -= leftw + rightw;

		if (leftw)
			blit_image(cur->background.left, cr, x, 0);
		x += leftw;

		pattern_image(cur->background.center, cr, x, 0,
				centerw, 1);
		x += centerw;

		if (rightw)
			blit_image(cur->background.right, cr, x, 0);
		x -= centerw;
	}

	draw_text(cr, w->panel->layout, &cur->font, buftime,
		  x, 0, centerw, w->panel->height, 0);
}

static void clock_tick(struct widget *w)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;

	static char buflasttime[128];
	char buftime[128];

	time_t current_time;
	current_time = time(0);
	strftime(buftime, sizeof(buftime), 
			cw->time_format, localtime(&current_time));
	if (!strcmp(buflasttime, buftime))
		return;
	strcpy(buflasttime, buftime);

	int nw = get_clock_width(w, buftime);
	if (nw != w->width) {
		w->width = nw;
		recalculate_widgets_sizes(w->panel);
		return;
	}
	w->needs_expose = 1;
}

static void button_click(struct widget *w, XButtonEvent *e)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;
	if (!cw->clock_prog)
		return;

	if (cw->mouse_button == e->button && e->type == ButtonRelease)
		g_spawn_command_line_async(cw->clock_prog, 0);
}

static void mouse_motion(struct widget *w, XMotionEvent *e)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;
	if (cw->highlighted != 1) {
		cw->highlighted = 1;
		w->needs_expose = 1;
	}
}

static void mouse_leave(struct widget *w)
{
	struct clock_widget *cw = (struct clock_widget*)w->private;
	if (cw->highlighted != -1) {
		cw->highlighted = -1;
		w->needs_expose = 1;
	}
}

static void reconfigure(struct widget *w)
{
}
