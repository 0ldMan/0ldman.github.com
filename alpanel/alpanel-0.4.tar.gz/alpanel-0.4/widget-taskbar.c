#include <ctype.h>
#include "builtin-widgets.h"

static int create_widget_private(struct widget *w, struct config_format_entry *ce,
		struct config_format_tree *ctree, struct config_format_tree *ttree);
static void destroy_widget_private(struct widget *w);
static void draw(struct widget *w);
static void button_click(struct widget *w, XButtonEvent *e);
static void prop_change(struct widget *w, XPropertyEvent *e);
static void client_msg(struct widget *w, XClientMessageEvent *e);
static void configure(struct widget *w, XConfigureEvent *e);

static void dnd_start(struct widget *w, struct drag_info *di);
static void dnd_drag(struct widget *w, struct drag_info *di);
static void dnd_drop(struct widget *w, struct drag_info *di);

static void mouse_motion(struct widget *w, XMotionEvent *e);
static void mouse_leave(struct widget *w);

static void clock_tick(struct widget *w);
static void reconfigure(struct widget *w);

struct widget_interface taskbar_interface = {
	.theme_name		= "taskbar",
	.size_type		= WIDGET_SIZE_FILL,
	.create_widget_private	= create_widget_private,
	.destroy_widget_private = destroy_widget_private,
	.draw			= draw,
	.button_click		= button_click,
	.prop_change		= prop_change,
	.dnd_start		= dnd_start,
	.dnd_drag		= dnd_drag,
	.dnd_drop		= dnd_drop,
	.client_msg		= client_msg,
	.configure		= configure,
	.mouse_motion		= mouse_motion,
	.mouse_leave		= mouse_leave,
	.clock_tick		= clock_tick,
	.reconfigure		= reconfigure
};

static unsigned int parse_task_visible_monitors(const char *str)
{
	if (!str)
		return 0;

	unsigned int bitarray = 0;
	const char *c = str;
	while (*c) {
		char *newc = 0;
		long int monitor = strtol(c, &newc, 10);
		c = newc;
		if (monitor <= 31)
			bitarray |= 1 << monitor;
		while (!isdigit(*c) && *c)
			c++;
	}
	return bitarray;
}

/**************************************************************************
  Taskbar theme
**************************************************************************/

static int parse_taskbar_state(struct taskbar_state *ts, const char *name,
		struct config_format_entry *e, struct config_format_tree *tree,
		int required)
{
	struct config_format_entry *ee = find_config_format_entry(e, name);
	if (!ee) {
		if (required)
			required_entry_not_found(e, name);
		ts->exists = 0;
		return -1;
	}

	if (parse_triple_image(&ts->background, ee, tree, 1))
		goto parse_taskbar_state_error_background;

	if (parse_text_info_named(&ts->font, "font", ee, 1))
		goto parse_taskbar_state_error_font;

	parse_2ints(ts->icon_offset, "icon_offset", ee);

	ts->exists = 1;
	return 0;

parse_taskbar_state_error_font:
	free_triple_image(&ts->background);
parse_taskbar_state_error_background:
	return -1;
}

static void free_taskbar_state(struct taskbar_state *ts)
{
	if (ts->exists) {
		free_triple_image(&ts->background);
		free_text_info(&ts->font);
	}
}

static int parse_taskbar_theme(struct taskbar_theme *tt,
		struct config_format_tree *ttree)
{
	struct config_format_entry *te = find_config_format_entry(&ttree->root,
			"task");
	if (!te) {
		required_entry_not_found(&ttree->root, "task");
		return -1;
	}

	if (parse_taskbar_state(&tt->states[BUTTON_STATE_IDLE],
				"idle", te, ttree, 1))
		goto parse_taskbar_button_theme_error_idle;

	if (parse_taskbar_state(&tt->states[BUTTON_STATE_ACTIVE],
				"active", te, ttree, 1))
		goto parse_taskbar_button_theme_error_active;

	struct config_format_entry *ee = find_config_format_entry(te,
			"default_icon");
	if (ee)
		tt->default_icon = parse_image_part(ee, ttree, 0);

	parse_taskbar_state(&tt->states[BUTTON_STATE_IDLE_HIGHLIGHT],
			"idle_highlight", te, ttree, 0);
	parse_taskbar_state(&tt->states[BUTTON_STATE_ACTIVE_HIGHLIGHT],
			"active_highlight", te, ttree, 0);

	tt->separator = parse_image_part_named("separator", te, ttree, 0);
	tt->task_max_width = parse_int("max_width", te, 0);

	struct config_format_entry *ge = find_config_format_entry(&ttree->root,
			"tasks");
	if (ge)
		tt->separator_gr = parse_image_part_named("separator", ge, ttree, 0);

	return 0;

parse_taskbar_button_theme_error_active:
	free_taskbar_state(&tt->states[BUTTON_STATE_IDLE]);
parse_taskbar_button_theme_error_idle:
	return -1;
}

static void free_taskbar_theme(struct taskbar_theme *tt)
{
	unsigned int i;
	for (i = 0; i < 4; ++i)
		free_taskbar_state(&tt->states[i]);
	if (tt->default_icon)
		cairo_surface_destroy(tt->default_icon);
	if (tt->separator)
		cairo_surface_destroy(tt->separator);
	if (tt->separator_gr)
		cairo_surface_destroy(tt->separator_gr);
}

/**************************************************************************
  Taskbar task management
**************************************************************************/

static int is_task_visible(struct widget *w, struct taskbar_task *task)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;

	int gooddesktop = tw->multi_desktop ? 
		1 : tw->desktop == task->desktop || task->desktop == -1;
	int goodmonitor = tw->task_visible_monitors ?
		tw->task_visible_monitors & (1 << task->monitor) :
		w->panel->monitor == task->monitor;

	return gooddesktop && goodmonitor;
}

static int task_monitor_coverage(int x, int y, int w, int h,
		const struct x_monitor *mon)
{
	return rect_coverage(&(struct rect){x, y, w, h},
			&(struct rect){mon->x, mon->y, mon->width, mon->height});
}

static int task_monitor(int x, int y, int w, int h,
		const struct x_monitor *monitors, int monitors_n)
{
	int task_monitor = -1;
	int maxcoverage = 0;
	int i;
	for (i = 0; i < monitors_n; ++i) {
		int coverage = task_monitor_coverage(x, y, w, h, &monitors[i]);
		if (coverage > maxcoverage) {
			task_monitor = i;
			maxcoverage = coverage;
		}
	}
	return task_monitor;
}

static int find_task_by_window(struct taskbar_widget *tw, Window win)
{
	size_t i;
	for (i = 0; i < tw->tasks_n; ++i) {
		if (tw->tasks[i].win == win)
			return (int)i;
	}
	return -1;
}

static int find_last_task_by_desktop(struct taskbar_widget *tw, int desktop)
{
	int t = -1;
	size_t i;
	for (i = 0; i < tw->tasks_n; ++i) {
		if (tw->tasks[i].desktop <= desktop)
			t = (int)i;
	}
	return t;
}

static void add_task(struct widget *w, struct x_connection *c, Window win)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	struct taskbar_task t;

	x_set_error_trap();
	if (!x_is_window_visible_on_panel(c, win)) {
		if (x_done_error_trap())
			return;
		/* we need this if window will apear later */
		if (w->panel->win != win)
			XSelectInput(c->dpy, win, PropertyChangeMask);
		return;
	}

	XWindowAttributes winattrs;
	XGetWindowAttributes(c->dpy, win, &winattrs);
	long mask = winattrs.your_event_mask | PropertyChangeMask | StructureNotifyMask;
	XSelectInput(c->dpy, win, mask);
	XGetWindowAttributes(c->dpy, win, &winattrs); /* get position after select input */

	CLEAR_STRUCT(&t);
	t.win = win;
	t.demands_attention = x_is_window_demands_attention(c, win);
	int x, y;
	x_translate_coordinates(c, 0, 0, &x, &y, win);
	t.monitor = task_monitor(x, y, 
			winattrs.width, winattrs.height, c->monitors, c->monitors_n);

	x_realloc_window_name(&t.name, c, win, &t.name_atom, &t.name_type_atom);
	t.icon = tw->is_icon && tw->theme.default_icon ?
		get_window_icon(c, win, tw->theme.default_icon) : 0;
	t.desktop = x_get_window_desktop(c, win);

	int i = find_last_task_by_desktop(tw, t.desktop);
	if (i == -1)
		ARRAY_PREPEND(tw->tasks, t);
	else
		ARRAY_INSERT_AFTER(tw->tasks, (size_t)i, t);
}

static void free_task(struct taskbar_task *t)
{
	strbuf_free(&t->name);
	if (t->icon)
		cairo_surface_destroy(t->icon);
}

static void remove_task(struct taskbar_widget *tw, size_t i)
{
	free_task(&tw->tasks[i]);
	ARRAY_REMOVE(tw->tasks, i);
}

static void free_tasks(struct taskbar_widget *tw)
{
	size_t i;
	for (i = 0; i < tw->tasks_n; ++i)
		free_task(&tw->tasks[i]);
	FREE_ARRAY(tw->tasks);
}

static int count_visible_tasks(struct widget *w)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	int count = 0;
	size_t i;
	for (i = 0; i < tw->tasks_n; ++i) {
		if (is_task_visible(w, &tw->tasks[i]))
			count++;
	}
	return count;
}

static int highlighted_state_exists(struct taskbar_theme *theme, int active)
{
	int state_hl = (active << 1) | 1;
	return theme->states[state_hl].exists ? 1 : 0;
}

static void draw_task(struct taskbar_task *task, struct taskbar_widget *tw,
		cairo_t *cr, PangoLayout *layout, int x, int w, 
		int active, int highlighted, int is_first, int is_last)
{
	struct taskbar_theme *theme = &tw->theme;

	if (tw->task_urgency_hint) {
		if (active)
			task->demands_attention = 0;

		if (task->demands_attention > 0) {
			if (highlighted_state_exists(theme, active))
				highlighted = task->demands_attention - 1;
			else
				active = task->demands_attention - 1;
		}
	}

	/* calculations */
	int state = active << 1;
	int state_hl = (active << 1) | highlighted;

	struct triple_image *tbt;
	struct text_info *font;
	int *icon_offset;
	if (theme->states[state_hl].exists) {
		tbt = &theme->states[state_hl].background;
		font = &theme->states[state_hl].font;
		icon_offset = theme->states[state_hl].icon_offset;
	} else {
		tbt = &theme->states[state].background;
		font = &theme->states[state].font;
		icon_offset = theme->states[state].icon_offset;
	}

	int leftw = image_width(tbt->left);
	int rightw = image_width(tbt->right);
	int height = image_height(tbt->tile);
	int centerw = w - leftw - rightw;

	int iconw = 0;
	int iconh = 0;
	if (tw->is_icon) {
		iconw = image_width(theme->default_icon);
		iconh = image_height(theme->default_icon);
	}
	int textw = centerw - (iconw + icon_offset[0]);

	/* background */
	int leftx = x;
	int centerx = x + leftw;
	int rightx = centerx + centerw;

	if (tbt->stretched_overlap)
		stretch_image(tbt->tile, cr,
				leftx + tbt->center_offsets[0], 0,
				w - tbt->center_offsets[0] - tbt->center_offsets[1]);
	else if (tbt->stretched)
		stretch_image(tbt->tile, cr,
				centerx + tbt->center_offsets[0], 0,
				centerw - tbt->center_offsets[0] - tbt->center_offsets[1]);
	else
		pattern_image(tbt->tile, cr, centerx, 0, centerw, 1);

	if (leftw) blit_image(tbt->left, cr, leftx, 0);
	if (rightw) blit_image(tbt->right, cr, rightx, 0);

	/* icon */
	int xx = centerx;
	if (iconw && iconh) {
		int yy = (height - iconh) / 2;
		xx += icon_offset[0];
		yy += icon_offset[1];
		cairo_save(cr);
		cairo_set_operator(cr, CAIRO_OPERATOR_OVER);
		blit_image(task->icon, cr, xx, yy);
		cairo_restore(cr);
	}
	xx += iconw;

	/* text */
	draw_text(cr, layout, font, task->name.buf, xx, 0, textw, height, 1);
}

static inline void activate_task(struct x_connection *c, struct taskbar_task *t)
{
	x_send_netwm_message(c, t->win, c->atoms[XATOM_NET_ACTIVE_WINDOW],
			2, CurrentTime, 0, 0, 0);

	XWindowChanges wc;
	wc.stack_mode = Above;
	XConfigureWindow(c->dpy, t->win, CWStackMode, &wc);
}

static inline void close_task(struct x_connection *c, struct taskbar_task *t)
{
	x_send_netwm_message(c, t->win, c->atoms[XATOM_NET_CLOSE_WINDOW],
			CurrentTime, 2, 0, 0, 0);
}

static void move_task(struct taskbar_widget *tw, int what, int where)
{
	struct taskbar_task t = tw->tasks[what];
	if (what == where)
		return;
	ARRAY_REMOVE(tw->tasks, (size_t)what);
	if (where > what) {
		where -= 1;
		ARRAY_INSERT_AFTER(tw->tasks, (size_t)where, t);
	} else {
		ARRAY_INSERT_BEFORE(tw->tasks, (size_t)where, t);
	}
}

static int get_taskbar_task_at(struct widget *w, int x)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	size_t i;
	for (i = 0; i < tw->tasks_n; ++i) {
		struct taskbar_task *t = &tw->tasks[i];
		if (!is_task_visible(w, t))
			continue;

		if (x < (t->x + t->w) && x > t->x)
			return (int)i;
	}
	return -1;
}

static int count_desktops(struct x_connection *c)
{
	int count = x_get_prop_int(c, c->root,
				      c->atoms[XATOM_NET_NUMBER_OF_DESKTOPS]);
	if (!count || count < 1)
		count = 1;
	return count;
}

static void switch_desktop(int desktop, struct x_connection *c)
{
	int desktops = x_get_prop_int(c, c->root,
				      c->atoms[XATOM_NET_NUMBER_OF_DESKTOPS]);
	if (desktop >= desktops)
		return;

	x_send_netwm_message(c, c->root, c->atoms[XATOM_NET_CURRENT_DESKTOP],
			desktop, 0, 0, 0, 0);
}

/**************************************************************************
  Updates
**************************************************************************/

static void update_active(struct taskbar_widget *tw, struct x_connection *c)
{
	tw->active = x_get_prop_window(c, c->root,
			c->atoms[XATOM_NET_ACTIVE_WINDOW]);
}

static void update_desktop(struct taskbar_widget *tw, struct x_connection *c)
{
	tw->desktop = x_get_prop_int(c, c->root,
			c->atoms[XATOM_NET_CURRENT_DESKTOP]);
}

static void update_tasks(struct widget *w, struct x_connection *c)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	Window *wins;
	int num;

	wins = x_get_prop_data(c, c->root, c->atoms[XATOM_NET_CLIENT_LIST],
			XA_WINDOW, &num);

	size_t i;
	int j;
	for (i = 0; i < tw->tasks_n; ++i) {
		struct taskbar_task *t = &tw->tasks[i];
		int delete = 1;
		for (j = 0; j < num; ++j) {
			if (wins[j] == t->win) {
				delete = 0;
				break;
			}
		}
		if (delete)
			remove_task(tw, i--);
	}

	for (j = 0; j < num; ++j)
		if (find_task_by_window(tw, wins[j]) == -1)
			add_task(w, c, wins[j]);

	XFree(wins);
}

/**************************************************************************
  Taskbar interface
**************************************************************************/

static int create_widget_private(struct widget *w, 
		struct config_format_entry *ce,
		struct config_format_tree *ctree, struct config_format_tree *ttree)
{
	struct taskbar_widget *tw = xmallocz(sizeof(struct taskbar_widget));
	if (parse_taskbar_theme(&tw->theme, ttree)) {
		xfree(tw);
		XWARNING("Failed to parse taskbar theme");
		return -1;
	}

	INIT_ARRAY(tw->tasks, MAX_TASK);
	w->private = tw;

	tw->is_icon = ! parse_bool("no_icon", ce);
	tw->multi_desktop = parse_bool("multi_desktop", ce);
	tw->switch_desktop_on_drop_task = parse_bool("switch_desktop_on_drop_task", ce);
	tw->task_death_threshold = parse_int("death_threshold", ce, 50);
	tw->task_urgency_hint = parse_bool("urgency_hint", ce);
	const char *tvmstr = find_config_format_entry_value(ce, "visible_monitors");
	tw->task_visible_monitors = parse_task_visible_monitors(tvmstr);

	struct x_connection *c = &w->panel->connection;
	update_desktop(tw, c);
	update_active(tw, c);
	update_tasks(w, c);
	
	tw->dnd_cur = XCreateFontCursor(c->dpy, XC_fleur);
	tw->dnd_win = None;
	tw->taken = None;
	tw->highlighted = -1;
	return 0;
}

static void destroy_widget_private(struct widget *w)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	free_taskbar_theme(&tw->theme);
	free_tasks(tw);
	XFreeCursor(w->panel->connection.dpy, tw->dnd_cur);
	xfree(tw);
}

static void draw(struct widget *w)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	struct taskbar_theme *tt = &tw->theme;
	struct panel *p = w->panel;
	struct x_connection *c = &p->connection;
	cairo_t *cr = p->cr;

	int count = count_visible_tasks(w);
	if (!count)
		return;

	int count_d = tw->multi_desktop ? count_desktops(c) : 1;

	int sepw = image_width(tt->separator);
	int sepgrw = image_width(tt->separator_gr);
	int sepspace = (count - 1) * sepw;
	int sepspace_gr = (count_d - (w->index == 0 ? 1 : 0)) * sepgrw;
	int taskw = (w->width - sepspace - sepspace_gr) / count;
	if (tt->task_max_width && taskw > tt->task_max_width)
		taskw = tt->task_max_width;

	int x = w->x;
	size_t i, j, k, kn, kj[MAX_TASK];

	for (i = 0; i < count_d; ++i) {

		for (j = 0, kn = 0; j < tw->tasks_n; ++j) {
			struct taskbar_task *t = &tw->tasks[j];
			if (i == t->desktop && is_task_visible(w, t))
				kj[kn++] = j;
		}
		/*if (!kn)     */
		/*    continue;*/

		/* group separator */
		if (sepgrw) {
			blit_image(tt->separator_gr, cr, x, 0);
			x += sepgrw;
		}

		for (k = 0; k < kn; ++k) {
			j = kj[k];
			struct taskbar_task *t = &tw->tasks[j];

			/* task separator */
			if (sepw && k != 0) {
				blit_image(tt->separator, cr, x, 0);
				x += sepw;
			}

			/* last task width correction */
			if (taskw != tt->task_max_width && i == count_d - 1 && k == kn - 1)
				taskw = (w->x + w->width) - x;

			/* save position for other events */
			t->x = x;
			t->w = taskw;

			/* set icon geometry */
			if (t->geom_x != t->x || t->geom_w != t->w) {
				t->geom_x = t->x;
				t->geom_w = t->w;

				long icon_geometry[4] = {
					w->panel->x + t->x,
					w->panel->y,
					t->w,
					w->panel->width
				};
				x_set_prop_array(c, t->win, c->atoms[XATOM_NET_WM_ICON_GEOMETRY],
						 icon_geometry, 4);
			}

			draw_task(t, tw, cr, w->panel->layout, x, taskw, 
					t->win == tw->active, j == tw->highlighted,
					k == 0, k == kn - 1);
			x += taskw;
		}
	}
}

static void prop_change(struct widget *w, XPropertyEvent *e)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	struct x_connection *c = &w->panel->connection;

	/* root window props */
	if (e->window == c->root) {
		if (e->atom == c->atoms[XATOM_NET_ACTIVE_WINDOW]) {
			update_active(tw, c);
			w->needs_expose = 1;
			return;
		}
		if (e->atom == c->atoms[XATOM_NET_CURRENT_DESKTOP]) {
			update_desktop(tw, c);
			w->needs_expose = 1;
			return;
		}
		if (e->atom == c->atoms[XATOM_NET_CLIENT_LIST]) {
			update_tasks(w, c);
			w->needs_expose = 1;
			return;
		}
	}

	/* check if it's our task */
	int ti = find_task_by_window(tw, e->window);
	if (ti == -1) {
		if (e->atom == c->atoms[XATOM_NET_WM_STATE] ||
		    e->atom == c->atoms[XATOM_NET_WM_WINDOW_TYPE]) {
			add_task(w, c, e->window);
		}
		return;
	}

	/* desktop changed (task was moved to other desktop) */
	if (e->atom == c->atoms[XATOM_NET_WM_DESKTOP]) {
		struct taskbar_task t = tw->tasks[ti];
		t.desktop = x_get_window_desktop(c, t.win);

		ARRAY_REMOVE(tw->tasks, (size_t)ti);
		int insert_after = find_last_task_by_desktop(tw, t.desktop);
		if (insert_after == -1)
			ARRAY_PREPEND(tw->tasks, t);
		else
			ARRAY_INSERT_AFTER(tw->tasks, (size_t)insert_after, t);
		w->needs_expose = 1;
		return;
	}

	/* task name was changed */
	if (e->atom == tw->tasks[ti].name_atom)
	{
		struct taskbar_task *t = &tw->tasks[ti];
		x_realloc_window_name(&t->name, c, t->win,
				&t->name_atom, &t->name_type_atom);
		w->needs_expose = 1;
		return;
	}

	/* icon was changed */
	if (tw->is_icon && tw->theme.default_icon) {
		if (e->atom == c->atoms[XATOM_NET_WM_ICON] ||
		    e->atom == XA_WM_HINTS)
		{
			struct taskbar_task *t = &tw->tasks[ti];
			cairo_surface_destroy(t->icon);
			t->icon = get_window_icon(c, t->win, tw->theme.default_icon);
			w->needs_expose = 1;
			return;
		}
	}

	if (e->atom == c->atoms[XATOM_NET_WM_STATE] ||
	    e->atom == c->atoms[XATOM_WM_STATE]) 
	{
		struct taskbar_task *t = &tw->tasks[ti];
		if (!x_is_window_visible_on_panel(c, t->win))
			remove_task(tw, ti);
		t->demands_attention = x_is_window_demands_attention(c, t->win);
		w->needs_expose = 1;
		return;
	}
}

static void button_click(struct widget *w, XButtonEvent *e)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	int ti = get_taskbar_task_at(w, e->x);
	if (ti == -1)
		return;
	struct taskbar_task *t = &tw->tasks[ti];
	struct x_connection *c = &w->panel->connection;

	int mbutton_use = check_mbutton_condition(w->panel, e->button, MBUTTON_USE);
	int mbutton_kill = check_mbutton_condition(w->panel, e->button, MBUTTON_KILL);

	if (e->type == ButtonRelease) {
		if (mbutton_use) {
			if (tw->active == t->win)
				XIconifyWindow(c->dpy, t->win, c->screen);
			else {
				if (!(tw->desktop == t->desktop || t->desktop == -1))
					switch_desktop(t->desktop, c);
				activate_task(c, t);
				w->panel->showing_desktop = 0;
			}
		}
		if (mbutton_kill)
			close_task(c, t);
	}
}

static Window create_window_for_dnd(struct x_connection *c, int x, int y,
				    cairo_surface_t *icon)
{
	int iconw = image_width(icon);
	int iconh = image_height(icon);

	/* background with an icon */
	Pixmap bg = x_create_default_pixmap(c, iconw, iconh);
	cairo_t *cr = create_cairo_for_pixmap(c, bg, iconw, iconh);

	cairo_set_source_rgba(cr, 0,0,0,1);
	cairo_paint(cr);
	blit_image(icon, cr, 0, 0);
	cairo_destroy(cr);

	XSetWindowAttributes attrs;
	attrs.background_pixmap = bg;
	attrs.override_redirect = True;

	/* the window */
	Window win = x_create_default_window(c, x, y, iconw, iconh,
			CWOverrideRedirect | CWBackPixmap, &attrs);
	XFreePixmap(c->dpy, bg);

	/* create shape for a window */
	Pixmap mask = XCreatePixmap(c->dpy, c->root, iconw, iconh, 1);
	cr = create_cairo_for_bitmap(c, mask, iconw, iconh);

	cairo_set_operator(cr, CAIRO_OPERATOR_SOURCE);
	cairo_set_source_rgba(cr, 0,0,0,0);
	cairo_paint(cr);
	blit_image(icon, cr, 0, 0);
	cairo_destroy(cr);

	XShapeCombineMask(c->dpy, win, ShapeBounding, 0, 0, mask, ShapeSet);
	XFreePixmap(c->dpy, mask);

	return win;
}

static void client_msg(struct widget *w, XClientMessageEvent *e)
{
	struct panel *p = w->panel;
	struct x_connection *c = &p->connection;
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;

	if (e->message_type == c->atoms[XATOM_XDND_POSITION]) {
		int x = (e->data.l[2] >> 16) & 0xFFFF;

		/* if it's not ours, skip.. */
		if ((x < (p->x + w->x)) || (x > (p->x + w->x + w->width)))
			return;

		int ti = get_taskbar_task_at(w, x - p->x);
		if (ti != -1) {
			struct taskbar_task *t = &tw->tasks[ti];
			if (t->win != tw->active) {
				activate_task(c, t);
				w->panel->showing_desktop = 0;
			}
		}

		x_send_dnd_message(c, e->data.l[0],
				c->atoms[XATOM_XDND_STATUS],
				p->win, 2, 0, 0, None); /* bits: 0 1 */
	}
}

static void dnd_start(struct widget *w, struct drag_info *di)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	struct x_connection *c = &w->panel->connection;

	int ti = get_taskbar_task_at(di->taken_on, di->taken_x);
	if (ti == -1)
		return;

	int mbutton_drag = check_mbutton_condition(w->panel, 
			di->button, MBUTTON_DRAG);
	if (!mbutton_drag)
		return;

	struct taskbar_task *t = &tw->tasks[ti];
	if (t->icon) {
		tw->dnd_win = create_window_for_dnd(c,
				di->cur_root_x, di->cur_root_y, t->icon);
		XMapWindow(c->dpy, tw->dnd_win);
	}

	XDefineCursor(c->dpy, w->panel->win, tw->dnd_cur);
	tw->taken = t->win;
}

static void dnd_drag(struct widget *w, struct drag_info *di)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	struct x_connection *c = &w->panel->connection;
	if (tw->dnd_win != None)
		XMoveWindow(c->dpy, tw->dnd_win, di->cur_root_x, di->cur_root_y);
}

static void dnd_drop(struct widget *w, struct drag_info *di)
{
	/* ignore dragged data from other widgets */
	if (di->taken_on != w)
		return;

	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	struct x_connection *c = &w->panel->connection;

	/* check if we have something draggable */
	if (tw->taken != None) {
		int taken = find_task_by_window(tw, tw->taken);
		int dropped = get_taskbar_task_at(w, di->dropped_x);
		if (di->taken_on == di->dropped_on &&
		    taken != -1 && dropped != -1)
		{
		    int desktop = tw->tasks[dropped].desktop;
			if (tw->tasks[taken].desktop != desktop) {
				if (tw->switch_desktop_on_drop_task)
					switch_desktop(desktop, c);
				x_send_netwm_message(c, tw->taken,
					c->atoms[XATOM_NET_WM_DESKTOP],
					(long)desktop, 2, 0, 0, 0);
			}
			/* if the desktop is the same.. move task */
			move_task(tw, taken, dropped);
			w->needs_expose = 1;
		} else if (!di->dropped_on && taken != -1) {
			/* out of the panel */
			if (di->cur_y < -tw->task_death_threshold ||
			    di->cur_y > w->panel->height + tw->task_death_threshold)
			{
				close_task(c, &tw->tasks[taken]);
			}
		}
	}

	XUndefineCursor(c->dpy, w->panel->win);

	if (tw->dnd_win != None) {
		XDestroyWindow(c->dpy, tw->dnd_win);
		tw->dnd_win = None;
	}
	tw->taken = None;
}

static void mouse_motion(struct widget *w, XMotionEvent *e)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	int i = get_taskbar_task_at(w, e->x);
	if (i != tw->highlighted) {
		tw->highlighted = i;
		w->needs_expose = 1;
	}
}

static void mouse_leave(struct widget *w)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	if (tw->highlighted != -1) {
		tw->highlighted = -1;
		w->needs_expose = 1;
	}
}

static void clock_tick(struct widget *w)
{
	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	size_t i;
	time_t seconds = time(0);
	for (i = 0; i < tw->tasks_n; ++i) {
		struct taskbar_task *t = &tw->tasks[i];
		if (t->demands_attention > 0) {
			w->needs_expose = 1;
			t->demands_attention = 1 + (seconds % 2);
		}
	}
}

static void configure(struct widget *w, XConfigureEvent *e)
{
	struct x_connection *c = &w->panel->connection;
	const struct x_monitor *monitors = c->monitors;
	int monitors_n = c->monitors_n;

	/* do nothing if there is only one monitor */
	if (monitors_n == 1)
		return;

	struct taskbar_widget *tw = (struct taskbar_widget*)w->private;
	int ti = find_task_by_window(tw, e->window);
	if (ti != -1) {
		struct taskbar_task *t = &tw->tasks[ti];

		/* figure out on which monitor task is located */
		XWindowAttributes winattrs;
		XGetWindowAttributes(c->dpy, e->window, &winattrs);

		int x, y;
		x_translate_coordinates(c, 0, 0, &x, &y, e->window);
		int monitor = task_monitor(x, y, 
				winattrs.width, winattrs.height, monitors, monitors_n);

		/* finally if task state is changed: redraw! */
		if (t->monitor != monitor) {
			t->monitor = monitor;
			w->needs_expose = 1;
		}
	}
}

static void reconfigure(struct widget *w)
{
}
