#include "builtin-widgets.h"

static int create_widget_private(struct widget *w, struct config_format_entry *ce,
		struct config_format_tree *ctree, struct config_format_tree *ttree);
static void destroy_widget_private(struct widget *w);

struct widget_interface space_interface = {
	.theme_name		= "space",
	.size_type		= WIDGET_SIZE_FILL,
	.create_widget_private	= create_widget_private,
	.destroy_widget_private = destroy_widget_private
};

/**************************************************************************
  Empty interface
**************************************************************************/

static int create_widget_private(struct widget *w, struct config_format_entry *ce,
		struct config_format_tree *ctree, struct config_format_tree *ttree)
{
	w->width = 0;
	w->private = 0;
	return 0;
}

static void destroy_widget_private(struct widget *w)
{
}
