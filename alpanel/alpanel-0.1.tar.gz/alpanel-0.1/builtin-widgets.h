#pragma once

#include "gui.h"
#include "widget-utils.h"
#include "array.h"

/* button states */
#define BUTTON_STATE_IDLE		0
#define BUTTON_STATE_IDLE_HIGHLIGHT	1
#define BUTTON_STATE_ACTIVE		2
#define BUTTON_STATE_ACTIVE_HIGHLIGHT	3

/**************************************************************************
  Combo bar
**************************************************************************/

struct combo_desktop {
	char *name;
	int x;
	int w;
	int textw;
};

struct combo_task {
	struct strbuf name;
	cairo_surface_t *icon;
	Window win;
	int desktop;
	int x;
	int w;
	int geom_x; /* for _NET_WM_ICON_GEOMETRY */
	int geom_w;
	int demands_attention;
	int monitor; /* for multihead setups */

	/* I'm using only one name source Atom and I'm watching it for
	 * updates.
	 */
	Atom name_atom;
	Atom name_type_atom;
};

struct desk_state {
	struct triple_image background;
	struct text_info font;
	int exists;
};

struct task_state {
	struct triple_image background;
	struct text_info font;
	int icon_offset[2];
	int exists;
};

struct combo_theme {
	struct desk_state desk_states[4];
	struct task_state task_states[4];
	cairo_surface_t *default_icon;
	int task_max_width;

	cairo_surface_t *separator;
	cairo_surface_t *separator_gr;
};

struct combo_widget {
	struct combo_theme theme;

	/* array */
	struct combo_desktop *desktops;
	size_t desktops_n;
	size_t desktops_alloc;

	/* array */
	struct combo_task *tasks;
	size_t tasks_n;
	size_t tasks_alloc;

	int desk_active;
	int desk_highlighted;

	Window task_active;
	int task_highlighted;

	int desktops_min;
	int desktops_width;

	Window dnd_win;
	Window taken;

	Cursor dnd_cur;

	/* parameters from alpanel.conf */
	int is_icon;
	int switch_desktop_on_drop_task;
	int all_desktops_tasks_visible;
	int task_death_threshold;
	int task_urgency_hint;
	unsigned int task_visible_monitors;
};

extern struct widget_interface combo_interface;

/**************************************************************************
  Taskbar
**************************************************************************/

struct taskbar_task {
	struct strbuf name;
	cairo_surface_t *icon;
	Window win;
	int desktop;
	int x;
	int w;
	int geom_x; /* for _NET_WM_ICON_GEOMETRY */
	int geom_w;
	int demands_attention;
	int monitor; /* for multihead setups */

	/* I'm using only one name source Atom and I'm watching it for
	 * updates.
	 */
	Atom name_atom;
	Atom name_type_atom;
};

struct taskbar_state {
	struct triple_image background;
	struct text_info font;
	int icon_offset[2];
	int exists;
};

struct taskbar_theme {
	struct taskbar_state states[4];
	cairo_surface_t *default_icon;
	int task_max_width;
	cairo_surface_t *separator;
	cairo_surface_t *separator_gr;
};

struct taskbar_widget {
	struct taskbar_theme theme;

	/* array */
	struct taskbar_task *tasks;
	size_t tasks_n;
	size_t tasks_alloc;

	Window active;
	int highlighted;
	int desktop;

	Window dnd_win;
	Window taken;

	Cursor dnd_cur;

	/* parameters from alpanel.conf */
	int is_icon;
	int multi_desktop;
	int switch_desktop_on_drop_task;
	int task_death_threshold;
	int task_urgency_hint;
	unsigned int task_visible_monitors;
};

extern struct widget_interface taskbar_interface;

/**************************************************************************
  Clock
**************************************************************************/

struct clock_state {
	struct triple_image background;
	struct text_info font;
	int exists;
};

struct clock_theme {
	struct clock_state states[4];
};

struct clock_widget {
	struct clock_theme theme;

	/* parameters from alpanel.conf */
	char *time_format;
	char *clock_prog;
	int mouse_button;

	int highlighted;
};

extern struct widget_interface clock_interface;

/**************************************************************************
  Desktop Switcher
**************************************************************************/

struct desktops_desktop {
	char *name;
	int x;
	int w;
	int textw;
	int visible;  /* bool */
};

struct desktops_state {
	cairo_surface_t *left_corner;
	struct triple_image background;
	cairo_surface_t *right_corner;
	struct text_info font;
	int exists;
};

struct desktops_theme {
	struct desktops_state states[4];
	cairo_surface_t *separator;
};

struct desktops_widget {
	struct desktops_theme theme;

	/* array */
	struct desktops_desktop *desktops;
	size_t desktops_n;
	size_t desktops_alloc;

	int active;
	int highlighted;

	/* parameters from alpanel.conf */
	int occupied_only;
};

extern struct widget_interface desktops_interface;

/**************************************************************************
  Decor
**************************************************************************/

struct decor_widget {
	cairo_surface_t *image;
};

extern struct widget_interface decor_interface;

/**************************************************************************
  Empty
**************************************************************************/

extern struct widget_interface empty_interface;

/**************************************************************************
  Systray
**************************************************************************/

struct systray_icon {
	Window icon;
	Window embedder;
	int mapped;
};

struct systray_theme {
	struct triple_image background;
	int icon_size[2];
	int icon_offset[2];
	int icon_spacing;
	int align;
};

struct systray_widget {
	/* array */
	struct systray_icon *icons;
	size_t icons_n;
	size_t icons_alloc;

	Atom tray_selection_atom;
	Window selection_owner;
	struct systray_theme theme;
};

extern struct widget_interface systray_interface;

/**************************************************************************
  Launch Bar
**************************************************************************/

struct launchbar_item {
	cairo_surface_t *icon;
	char *execstr;
	int x;
	int w;
};

struct launchbar_theme {
	struct triple_image background;
	int icon_size[2];
	int icon_offset[2];
	int icon_spacing;
};

struct launchbar_widget {
	struct launchbar_theme theme;

	/* parameters from alpanel.conf */
	/* array */
	struct launchbar_item *items;
	size_t items_n;
	size_t items_alloc;

	int active;
};

extern struct widget_interface launchbar_interface;
