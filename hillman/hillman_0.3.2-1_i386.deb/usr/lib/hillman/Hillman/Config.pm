package Hillman::Config;

use warnings;
use strict;
use utf8;
use Encode qw(decode_utf8);

use Hillman::Util qw(_try_open);

my ($app,$conf,$confdir,$conffile);

sub init {
	my ($class,$_app) = @_;
	$app = $_app;
	$conf = $$app{conf};
	$confdir = $ENV{HOME}.'/.hillman/';
	$conffile = $confdir.'hillman.conf';
	_load_conf();
}

sub save { _save_conf(); }
sub quit { _save_conf(); }

#--------------------------- sub --------------------------#

sub _load_conf {
	my ($sect,$k,$v);
	eval {
		open FILE,'<',$conffile or die "Can't open $conffile: $!\n";
		while (<FILE>) {
			chomp;  s/^\s+//;  s/\s+$//;  s/^[#;].*//;
			next unless length;
			if (m/^\[(.+)\]$/) { $sect = $1; next; }
			next unless m/=/;
			next if m/^_/;
			($k,$v) = split(/\s*=\s*/,$_,2);
			next unless $k;
			if ($sect eq 'Hillman') {
				$$conf{$k} = decode_utf8($v);
			} else {
				$$conf{_}{$sect}{$k} = decode_utf8($v);
			}
		}
		close FILE;
	1};
	warn "error eval: ",$@,"\n" if $@;
}

sub _save_conf {
	if (my $fh = _try_open('>',$conffile)) {

		use bytes;
		print $fh 
			"### hillman.conf, carefully edit, saved automatically.\n\n[Hillman]\n",
			join("\n", map $_.'='.$$conf{$_}, grep !/^_/, sort keys %$conf),"\n";
		
		my $href1 = $$conf{_} ||= {};

		foreach my $sect (sort grep $_, keys %$href1) {
			my $href2 = $$href1{$sect} ||= {};
			print $fh 
				"\n[$sect]\n",
				join("\n", map $_.'='.$$href2{$_}, sort keys %$href2),"\n";
		}
	}
}

1;
#--------------------------- end --------------------------#

