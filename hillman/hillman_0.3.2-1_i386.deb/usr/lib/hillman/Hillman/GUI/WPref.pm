package Hillman::GUI::WPref;

use warnings;
use strict;
use Gtk2;

use Hillman::Util qw(_ sig_conn sig_emit);

use base 'Gtk2::Window';

my ($app,$conf,$tips);
my (%entries,%spinners,%chkboxes,%choosers,@buttons);
my (%opts);

my $ntfy_list = [
	'play sound.wav',
	'aplay /usr/share/hillman/sounds/pling.wav',
	'echo "disk %n %d" | festival',
];
my $fman_list = [
	'pcmanfm %m',
	'thunar %m',
	'urxvt -e mc %m',
	'xterm -e mc %m',
];

sub _init_opts {
	my $dir = $Hillman::PREFIX.'/share/hillman/pixmaps/';
	return (		# key => [label, default, tooltip]
		view_hidden    => [ _('View Hidden Disks'),         0, undef ],
		info_in_prop   => [ _('View Info in Disk Property'),0, undef ],
		start_in_tray  => [ _('Start in Tray'),             0, undef ],
		use_clipboard  => [ _('Copy mount point when mount'), 0, undef ],
		sudo_for_mount => [ _('Sudo for mount'),            0, undef ],
		sudo_for_mkdir => [ _('Sudo for make directory'),   0, undef ],
		sudo_askpass   => [ _('Use sudo askpass program'),  0, undef ],
		wrapper        => [ _('Alternate commands:'),       0, undef ],
		wrapper_mount  => [ _('mount'), 'hillman_mount /dev/%d %m %t %o', undef ],
		wrapper_umount => [ _('umount'),'hillman_umount /dev/%d %m',      undef ],

		on_catch_run   => [ _('On device catch command'), 0, undef ],
		on_loss_run    => [ _('On device loss command'),  0, undef ],
		on_mount_run   => [ _('On mount command'),        0, undef ],
		on_umount_run  => [ _('On umount command'),       0, undef ],

		name   => [ _('Name'),             0, undef ],
		point  => [ _('Fixed mountpoint'), 0, undef ],
		hide   => [ _('Hide'),             0, undef ],
		mem    => [ _('Memorize'),         0, undef ],
	);
}

sub new {
	my ($class,$_app) = @_;
	%opts = _init_opts();
	$app = $_app;
	$conf = $$app{conf};
	my $wmain = $$app{wmain};
	_default_conf($conf) unless %$conf && scalar(keys %$conf) > 1;
	my $self = bless Gtk2::Window->new('toplevel'),$class;
	$self->set_title(join(' ',$Hillman::NAME,_('Preferences')));
	$self->set_icon($wmain->get_icon());
	$self->set_position('center');
	$self->set_default_size(200,200);
	$self->signal_connect('delete_event', sub { $self->hide(); 1; });

	$tips = Gtk2::Tooltips->new();

	my $box = Gtk2::VBox->new(0,0);
	my $bar = _button_bar($self);

	my $tabs = Gtk2::Notebook->new();
	$tabs->set_tab_pos('left');

	_add_tab($tabs,_('Common'),_tab_common());
	#_add_tab($tabs,_('Columns'),_tab_columns());
	_add_tab($tabs,_('FS'),_tab_fs());
	_add_tab($tabs,_('Secure'),_tab_secure());
	_add_tab($tabs,_('Commands'),_tab_cmds());
	_add_tab($tabs,_('Macro'),_tab_macro());

	$box->pack_start($tabs,1,1,0);
	$box->pack_start($bar,0,0,0);
	$box->show_all();
	$self->add($box);
	$self->realize();
	$self->hide();
	$self->set_transient_for($wmain);
	$app->{wpref} = $self;
	return $self;
}

sub show_item_prop {
	#warn "SHOW_ITEM_PROP. ",@_,"\n";
	my ($self,$key,$dev,$name,$point,$type) = @_;
	my $href = $$conf{_}{$key} ||= {};

	my $table = Gtk2::Table->new(6,2);		# 6 rows 2 cols
	$table->set_row_spacings(5);
	$table->set_col_spacings(12);
	$table->set_border_width(8);

	$table->attach_defaults(_prompt($dev||''),0,2,1,2);
			# name: entry
	my $entry_name = Gtk2::Entry->new();
	$entry_name->set_text($$href{name}) if $$href{name};
	$table->attach_defaults(_prompt('name'),0,1,2,3);
	$table->attach_defaults($entry_name,1,2,2,3);
	#        # point: entry
	#my $entry_point = Gtk2::Entry->new();
	#$entry_point->set_text($$href{point}) if $$href{point};
	#$table->attach_defaults(_prompt('point'),0,2,3,4);
	#$table->attach_defaults($entry_point,0,2,4,5);
			# point: combo entry
	my $list = Hillman::Engine::ls_media();
	my $combo_point = Gtk2::ComboBoxEntry->new_text();
	$combo_point->append_text($_) foreach @$list;
	my $entry_point = $combo_point->child;
	$entry_point->set_text($$href{point}) if $$href{point};
	$table->attach_defaults(_prompt('point'),0,2,3,4);
	$table->attach_defaults($combo_point,0,2,4,5);

	my $box = Gtk2::HBox->new(0,5);
			# mem: chkbox
	my $button_mem = Gtk2::CheckButton->new_with_label($opts{mem}[0]);
	$button_mem->set_active(1) if exists $$href{name};
	$box->pack_end($button_mem,0,1,0);
			# hide: chkbox
	my $button_hide = Gtk2::CheckButton->new_with_label($opts{hide}[0]);
	$button_hide->set_active(1) if $$href{hide};
	$box->pack_end($button_hide,0,1,0);
	$table->attach_defaults($box,0,2,5,6);

	$button_hide->signal_connect('toggled', sub { $button_mem->set_active(1) if 
				$button_hide->get_active() && !$button_mem->get_active(); });

	my $dialog = Gtk2::Dialog->new();
	$dialog->set_title(join(' ',$Hillman::NAME,_('Disk'),($name||()),($dev||())));
	$dialog->set_icon($self->get_icon());
	$dialog->set_modal(1);

	my $is_m = Hillman::Engine::get_mount($dev);
	my $oper = $is_m ? _('_Umount') : _('_Mount');
	$dialog->add_buttons($oper=>'yes','gtk-cancel'=>'cancel','gtk-ok'=>'ok');
	#$dialog->vbox->pack_start(_disk_info_frame($href),0,1,0) if $$conf{info_in_prop};
	$dialog->vbox->pack_start($table,0,1,0);

	$dialog->signal_connect('response', sub {
			#warn "RESPONSE. ",@_,"\n";
			my (undef,$v) = @_;

			if ($v && $v eq 'yes') {
				Glib::Idle->add(sub{ 
						$self->sig_emit('do',$key,$dev,$name,$point,$type); 0; });

			} elsif ($v && $v eq 'ok') {
				if ($button_mem->get_active()) {
					$$href{name} = $entry_name->get_text();
					$$href{point} = $entry_point->get_text();
					$$href{hide} = $button_hide->get_active();
				} else {
					delete($$conf{_}{$key});
				}
				Hillman::Config::save();
				Glib::Idle->add(sub{ $self->sig_emit('conf_changed'); 0; });
			}
			$dialog->destroy();
		});

	$dialog->show_all();
	$dialog->run();
	return 1;
}

sub _disk_info_frame {
	my ($href) = @_;
	my @tags = qw(dev point);
	my $frame = Gtk2::Frame->new(_('Info'));
	$frame->set_border_width(7);
	my $table = Gtk2::Table->new(scalar(@tags),2);	# N rows 2 cols
	$table->set_row_spacings(5);
	$table->set_col_spacings(12);
	$table->set_border_width(8);
	#warn " = '",join(' ', sort keys %$href),"'\n";
	my $i = 0;
	foreach (@tags) {
		$table->attach_defaults(_prompt($_),0,1,$i,$i+1);
		$table->attach_defaults(_prompt($$href{$_}),1,2,$i,$i+1);
		++$i;
	}
	$frame->add($table);
	return $frame;
}

sub on_keys {
	my ($self,$keys) = @_;
	my ($car,$key);
	my $href1 = $$conf{_} ||= {};
	foreach (@$keys) {
		($car,$key) = @$_;
		next unless $car;
		my $href2 = $$href1{$car} ||= {};
		$$href2{name} ||= $car;
		$$href2{color} ||= 'ffffff';
		$$href2{tout} = 0 unless defined $$href2{tout};
	}
	return 1;
}

#---------------------- notebook tabs ---------------------#

sub _tab_common {		##--- Common tab
	my @tags1 = qw(start_in_tray);
	my @tags2 = qw(use_clipboard);
	my $frame1 = Gtk2::Frame->new(_('Start'));
	my $frame2 = Gtk2::Frame->new(_('Clipboard'));
	my $box = Gtk2::VBox->new(0,5);
	my $box1 = Gtk2::VBox->new(0,5);
	my $box2 = Gtk2::VBox->new(0,5);
	$box1->set_border_width(10);
	$box2->set_border_width(10);
	$box1->pack_start(_chkbox($_),0,1,0) foreach @tags1;
	$box2->pack_start(_chkbox($_),0,1,0) foreach @tags2;
	$frame1->add($box1);
	$frame2->add($box2);
	$box->pack_start($frame1,0,1,0);
	$box->pack_start($frame2,0,1,0);
	return $box;
}

sub _tab_columns {		##--- Columns tab
	my $table = Gtk2::Table->new(1,2);		# 1 rows 2 cols
	$table->set_row_spacings(5);
	$table->set_col_spacings(12);
	return $table;
}

sub _tab_fs {   		##--- Filesystems tab
	my @arr = sort grep /^fs_/, keys %$conf;
	my $table = Gtk2::Table->new(scalar(@arr),2);	# N rows 2 cols
	$table->set_row_spacings(5);
	$table->set_col_spacings(12);
	#warn " - '",$_,"'\n" foreach @arr;
	my $i = 0;
	foreach (@arr) {
		m/^fs_(\w+)$/;
		$table->attach(_prompt($1),0,1,$i,$i+1,'fill','fill',0,0);
		$table->attach_defaults(_entry($_),1,2,$i,$i+1);
		++$i;
	}
	return $table;
}

			# Альтернативные команды [монтировать размонтировать]
sub _tab_secure {		##--- Secure tab
	my @tags = qw(sudo_for_mount sudo_for_mkdir sudo_askpass);
	my $box = Gtk2::VBox->new(0,5);
	$box->pack_start(_chkbox($_),0,1,0) foreach @tags;
	$box->pack_start(Gtk2::Label->new(''),0,1,0);
	$box->pack_start(_chkbox('wrapper'),0,1,0);

	my $table = Gtk2::Table->new(2,2);	# 2 rows 2 cols
	$table->set_row_spacings(5);
	$table->set_col_spacings(12);
	my $i = 0;
	foreach (qw(wrapper_mount wrapper_umount)) {
		$table->attach(_prompt($_),0,1,$i,$i+1,'fill','fill',0,0);
		$table->attach_defaults(_entry($_),1,2,$i,$i+1);
		++$i;
	}
	$box->pack_start($table,0,1,0);
	return $box;
}

sub _tab_cmds {			##--- Commands tab
	my @tags = qw(on_catch on_loss on_mount on_umount);
	my $box = Gtk2::VBox->new(0,5);
	$box->pack_start(_prompt(_('Launch Commands')),0,1,0);
	foreach (@tags) {
		$box->pack_start(_chkbox($_.'_run'),0,1,0);
		$box->pack_start(_combo_entry($_.'_command',
				m/on_mount$/ ? $fman_list : $ntfy_list),0,1,0);
	}
	return $box;
}

sub _tab_macro {		##--- Macro tab
			# "В командах можно использовать переменные:"
			# "В опциях ФС можно использовать переменные:"
	my $content = join("\n",
		'',_('Substitution variables may be used in commands:'),
		"\t".'%n - disk name',
		"\t".'%d - device',
		"\t".'%m - mount point',
		"\t".'%t - fs type',
		"\t".'%o - fs type options',
		"\t".'%s - disk size',
		"\t".'%p - percent of used',
		"\t".'%u - user id',
		"\t".'%g - group id',
		"\t".'%% - "%"',
		_('Substitution variables may be used in FS options:'),
		"\t".'%u - user id',
		"\t".'%g - group id',
		''
	);
	my $tv = Gtk2::TextView->new();
	$tv->set_editable(0);
	$tv->set_cursor_visible(0);
	$tv->set_left_margin(5);
	$tv->set_right_margin(5);
	my $buf = $tv->get_buffer();
	$buf->set_text($content);
	return $tv;
}

#---------------------- form widgets ----------------------#

sub _prompt {		# new aligned label
	my ($key) = @_;
	my $align = Gtk2::Alignment->new(0,0.5,0,0);
	my $label = Gtk2::Label->new(($opts{$key} ? $opts{$key}[0] : $key).':');
	$align->add($label);
	return $align;
}

sub _entry {		# new entry
	my ($key) = @_;
	my $entry = Gtk2::Entry->new();
	$entry->set_text($$conf{$key}) if $$conf{$key};
	$entry->signal_connect('changed',\&_set_changed);
	$tips->set_tip($entry,$opts{$key}[2]) if $opts{$key}[2];
	$entries{$key} = $entry;
	return $entry;
}

sub _combo_entry {		# new combo box entry
	my ($key,$list) = @_;
	$list ||= [];
	my $combo = Gtk2::ComboBoxEntry->new_text();
	$combo->append_text($_) foreach @$list;
	my $entry = $combo->child;
	$entry->set_text($$conf{$key}) if $$conf{$key};
	$entry->signal_connect('changed',\&_set_changed);
	$tips->set_tip($entry,$opts{$key}[2]) if $opts{$key}[2];
	$entries{$key} = $entry;
	return $combo;
}

# value: Начальное значение.
# lower: Минимальное значение.
# upper: Максимальное значение.
# step:  Шаг приращения.

sub _spinner {		# new spinner
	my ($key,$value,$lower,$upper,$step) = @_;
	$step ||= 1;		# optional, default = 1
	my $adj = Gtk2::Adjustment->new($value,$lower,$upper,$step,1,0);
	my $spinner = Gtk2::SpinButton->new($adj,1,0);
	$spinner->set_value($$conf{$key}) if $$conf{$key};
	$spinner->signal_connect('changed',\&_set_changed);
	$tips->set_tip($spinner,$opts{$key}[2]) if $opts{$key}[2];
	$spinners{$key} = $spinner;
	return $spinner;
}

sub _chkbox {		# new checkbox
	my ($key) = @_;
	my $button = Gtk2::CheckButton->new_with_label($opts{$key}[0]);
	#warn " - $key = '",$$conf{$key},"'.\n";
	$button->set_active($$conf{$key}) if $$conf{$key};
	$button->signal_connect('toggled',\&_set_changed);
	$tips->set_tip($button,$opts{$key}[2]) if $opts{$key}[2];
	$chkboxes{$key} = $button;
	return $button;
}

sub _chooser {		# new chooser
	my ($key,$dir) = @_;
	my $preview = Gtk2::Image->new();
	my $button = Gtk2::FileChooserButton->new('','open');
	$button->set_current_folder($dir);
	$button->set_filename($$conf{$key}) if $$conf{$key};
	$button->set_preview_widget($preview);
	$button->signal_connect('update-preview',\&_preview_handler,$preview);
	$button->signal_connect('selection-changed',\&_set_changed);
	$tips->set_tip($button,$opts{$key}[2]) if $opts{$key}[2];
	$choosers{$key} = $button;
	return $button;
}

#------------------------- handler ------------------------#

sub _preview_handler {
	my ($chooser,$img) = @_;
	my $filename = $chooser->get_preview_filename();
	if ($filename && -f $filename) {
		my ($pixbuf);
		eval { $pixbuf = Gtk2::Gdk::Pixbuf->new_from_file_at_size($filename,64,64); };
		if ($pixbuf) {
			$img->set_from_pixbuf($pixbuf);
			$chooser->set_preview_widget_active(1);
			return 1;
		}
	}
	$chooser->set_preview_widget_active(0);
	return 1;
}

#--------------------------- sub --------------------------#

sub _hbox {
	my $box = Gtk2::HBox->new(0,5);
	$box->pack_start($_,0,0,1) foreach @_;
	return $box;
}

sub _set_depends {
	my ($master,@slaves) = @_;
	my $is_active = $master->get_active();
    $_->set_sensitive($is_active) foreach @slaves;
	$master->signal_connect(toggled => sub {
		my $is_active = $master->get_active;
		$_->set_sensitive($is_active) foreach @slaves;
	});
}

sub _set_changed {
	$_->set_sensitive(1) foreach @buttons;
}

sub _add_tab {
	my ($tabs,$name,$widget) = @_;
	if ($widget =~ m/ScrolledWindow/) {
		$widget->set_border_width(2);
		$tabs->append_page($widget," $name ");		# tab label
	} else {
		my $box = Gtk2::VBox->new(0,5);
		$box->set_border_width(25);
		$box->pack_start($widget,0,1,0);
		$tabs->append_page($box," $name ");		# tab label
	}
}

sub _button_bar {
	my ($self) = @_;
	my $box = Gtk2::HButtonBox->new();
	$box->set_layout('end');
	$box->set_spacing(5);
	$box->set_border_width(5);

	my $apply = Gtk2::Button->new_from_stock('gtk-apply');
	my $cancel = Gtk2::Button->new_from_stock('gtk-cancel');
	my $ok = Gtk2::Button->new_from_stock('gtk-ok');

	$apply->signal_connect('clicked', sub { _apply($self); });
	$cancel->signal_connect('clicked', sub { _cancel(); $self->hide(); 1; });
	$ok->signal_connect('clicked', 
		sub { _apply($self) if $apply->get('sensitive'); $self->hide(); 1; });

	$box->add($apply);
	$box->add($cancel);
	$box->add($ok);
	@buttons = ($apply);		# or ($apply,$ok);
	$_->set_sensitive(0) foreach @buttons;
	Glib::Timeout->add(900, sub {			# chooser bug :(
			$_->set_sensitive(0) foreach @buttons; 0; });
	return $box;
}

sub _apply {
	my ($self) = @_;
	$$conf{$_} = $entries{$_}->get_text() foreach keys %entries;
	$$conf{$_} = $spinners{$_}->get_value() foreach keys %spinners;
	$$conf{$_} = $chkboxes{$_}->get_active() foreach keys %chkboxes;
	my (@tags);
	foreach (keys %choosers) {
		my $x = $choosers{$_}->get_filename();
		if ($x && $x ne $$conf{$_}) {
			push(@tags,$_);
			$$conf{$_} = $x;
		}
	}
	$_->set_sensitive(0) foreach @buttons;
	#warn "[+] _apply conf: $conf.\n";
	#warn join("\n", map { $_." = '".$$conf{$_}."'" } sort keys %$conf),"\n";
	Hillman::Config::save();
	Glib::Idle->add(sub{ 
			$self->sig_emit('conf_changed'); 
			$self->sig_emit('img_changed',@tags) if @tags;
			0; });
	return 1;
}

sub _cancel {
	$entries{$_}->set_text($$conf{$_}||'') foreach keys %entries;
	$spinners{$_}->set_value($$conf{$_}) foreach keys %spinners;
	$chkboxes{$_}->set_active($$conf{$_}) foreach keys %chkboxes;
	$$conf{$_} || $choosers{$_}->set_filename($$conf{$_}) foreach keys %choosers;
	$_->set_sensitive(0) foreach @buttons;
	return 1;
}

sub _default_conf {
	my ($conf) = @_;
	$$conf{$_} = $opts{$_}[1] foreach keys %opts;
	return 1;
}

1;
#--------------------------- end --------------------------#

