package Hillman::GUI;

use warnings;
use strict;
use Gtk2;

use Hillman::GUI::WMain;
use Hillman::GUI::WPref;
use Hillman::Util qw(sig_conn);

my ($gui,$w_main,$w_pref);
my ($tips,$ui);

sub init {
	my ($class,$app) = @_;
	Gtk2->init();

	$w_main = Hillman::GUI::WMain->new($app);
	$w_pref = Hillman::GUI::WPref->new($app);

	$w_pref->sig_conn('do', sub { shift; Hillman::Engine::do(@_); });
	$w_pref->sig_conn('conf_changed',\&Hillman::GUI::WMain::refresh);
}

sub run { Gtk2->main(); }
sub quit { Gtk2->main_quit(); }

1;
#--------------------------- end --------------------------#

