package Hillman;

use warnings;
use strict;
use utf8;
use Locale::gettext;

use Hillman::Config;
use Hillman::Engine;
use Hillman::GUI;

use base 'Exporter';

use vars qw($PREFIX $LIBDIR $PIXDIR $NAME $VERSION $LICENSE $URL $AUTHOR $LOGO $ICON);

our $NAME		= 'Hillman';
our $VERSION	= '0.3.2';
our $LICENSE	= 'GNU General Public License (GPL)';
our $URL		= 'http://hillman.eltra.ru';
our $AUTHOR		= 'Andrey Teleshov AKA OldMan';
our $LOGO		= 'logo.png';
our $ICON		= 'icon.png';
our $PIXDIR		= 'share/hillman/pixmaps';

our $debug = 0;
our $app = { conf => {} };

### app:  conf wmain wpref
### conf: _

sub init {
	$0 = my $name = lc($NAME);
	$PIXDIR = join('/',$PREFIX,$PIXDIR);
	$LOGO = join('/',$PIXDIR,$LOGO);
	$ICON = join('/',$PIXDIR,$ICON);
	bindtextdomain($name,sprintf('%s/share/locale',$PREFIX));
	bind_textdomain_codeset($name,'UTF8');
	textdomain($name);

	Hillman::Config->init($app);
	Hillman::GUI->init($app);
	Hillman::Engine->init($app);
	Hillman::GUI->run();
}

sub quit {
	Hillman::Config->quit();
	Hillman::Engine->quit();
	Hillman::GUI->quit();
}

sub debug { $debug = 1 }

1;
#--------------------------- end --------------------------#
