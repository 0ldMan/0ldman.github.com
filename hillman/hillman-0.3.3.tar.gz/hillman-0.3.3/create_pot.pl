#!/usr/bin/perl

use strict;
use warnings;

my $dir = $ENV{PWD};
my @files = (
	$dir.'/lib/Hillman.pm',
	$dir.'/lib/Hillman/Engine.pm',
	$dir.'/lib/Hillman/GUI.pm',
	glob($dir.'/lib/Hillman/GUI/*.pm'),
);

my %msgid;
my $version;

foreach my $file (@files) {
	warn "reading file $file\n";
	open my $fh,$file or die $!;
	$file =~ s/^$dir\///o;

	while (<$fh>) {
		next if m/^\s*#/;
		if (!$version && m/VERSION\s*=\s*['"]([0-9]+\.[0-9]+\.*[0-9]*)['"]/) { $version = $1 }
		while (m/_\("([^"]+)"\)/g)	{ $msgid{$1} .= " $file:$."; }
		while (m/_\('([^']+)'\)/g)	{ $msgid{$1} .= " $file:$."; }
	}
	close $fh;
}

$version ||= 'VERSION';
my ($year) = (localtime)[5];
$year += 1900;
$year = '2010-'.$year unless $year eq '2010';
my $date = `date --iso-8601=minutes`; 
$date =~ s/\n//g; 
$date =~ s/T/ /; 

my $file = join('/',$dir,'src','po','hillman.pot');
warn "\nwriting file $file\n";
open my $fh,'>',$file or die $!;

print $fh join("\n",
	'# Hillman, LANGUAGE language file',
	'# Copyright (c) '.$year,
	'# This file is distributed under the same license as the Hillman package.',
	'',
	#'#, fuzzy',
	'msgid ""',
	'msgstr ""',
	#'',
	'"Project-Id-Version: '.$version.'\n"',
	'"Report-Msgid-Bugs-To: Andrey Teleshov AKA OldMan <tele-post@mail.ru>\n"',
	'"POT-Creation-Date: '.$date.'\n"',
	'"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n"',
	'"Last-Translator: FULL NAME <EMAIL@ADDRESS>\n"',
	'"Language-Team: LANGUAGE <LL@li.org>\n"',
	'"MIME-Version: 1.0\n"',
	'"Content-Type: text/plain; charset=UTF-8\n"',
	'"Content-Transfer-Encoding: 8bit\n"',
	"\n"
);

foreach my $msg (sort { $msgid{$a} cmp $msgid{$b} } keys %msgid) {
	print $fh qq(#:$msgid{$msg}\nmsgid "$msg"\nmsgstr ""\n\n);
}
close $fh;

warn "to update LANGUAGE.po, run: msgmerge -s -U src/po/LANGUAGE.po src/po/hillman.pot\n";

