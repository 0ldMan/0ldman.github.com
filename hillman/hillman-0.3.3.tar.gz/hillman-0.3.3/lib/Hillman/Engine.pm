package Hillman::Engine;

use warnings;
use strict;
use utf8;
use Encode qw(decode_utf8);

use constant { TIMEOUT => 20 };

my %fs_default = (
	ext2	=> 'defaults,noatime',
	ext3	=> 'defaults,noatime',
	ext4	=> 'defaults,noatime',
	ntfs	=> 'uid=%u,gid=%g,noatime,nodiratime,umask=0,utf8',
	vfat	=> 'uid=%u,gid=%g,showexec,rw,noatime,nodiratime,quiet,async,utf8',
	iso9660	=> 'ro,unhide,utf8',
);

my $file_fstab = '/etc/fstab';
my $file_mtab  = '/etc/mtab';
my $dir_dev    = '/dev';
my $dir_block  = '';
my @dir_bl_alt = ('/dev/block','/dev/disk/by-path');
my $dir_id     = '/dev/disk/by-id';
my $dir_uuid   = '/dev/disk/by-uuid';
my $dir_media  = '/media';

my $cmd_df     = 'LANG=C /bin/df -hlPT';
my $cmd_info   = '/sbin/udevadm info -q env -n';	# <dev>
my $cmd_lsof   = 'LANG=C /usr/sbin/lsof';
my @cmd_sudo   = ('/usr/bin/sudo');			# -A|-S
my @cmd_mount  = ('/bin/mount');			# <-t fstype><-o options><dev><point>
my @cmd_umount = ('/bin/umount');			# <point>
my @cmd_mkdir  = ('/bin/mkdir');			# <point>
my @cmd_notify = ('/usr/bin/inotifywait','-q','-e','create','-e','delete');	# <file>

my %macro = (d =>'dev',n =>'name',m =>'point',s =>'size',t =>'type',p =>'pc');

my ($app,$conf,$child_pid,%children,$debug);

#----------------------- interface ------------------------#

sub init {
	my ($class,$_app) = @_;
	my ($k,$v);
	$app = $_app;
	$conf = $$app{conf};
	$$conf{"fs_$_"} ||= $fs_default{$_} foreach keys %fs_default;

	($dir_block) = grep -d,$dir_block,@dir_bl_alt; 
	warn "Can't find block devices directory among ",
			join(', ', map "'$_'",@dir_bl_alt),".\n" unless $dir_block;

	$debug = $Hillman::debug;
	$SIG{INT}  = \&Hillman::quit;
	$SIG{TERM} = \&Hillman::quit;
	$SIG{CHLD} = 'IGNORE';

	_inotify_start();
	return 1;
}

sub quit      { _inotify_stop();    1; }
sub do        { return _do(@_);        }
sub get_data  { return _disks();       }
sub get_mount { return _get_mount(@_); }	# IN: $dev; OUT: $mnt|undef
sub ls_media  { return _ls_media();    }

###       conf   real
###       ----   ----
### key:  uuid   uuid
### val:         is_m
###       name
###              dev
###       type   type
###       size   size
###              used,free,pc
###       point  point
###       hide
###
### no order!!!

#----------------------- wmain call -----------------------#

sub _note { $$app{wmain}->note(@_);        }
sub _rfsh { $$app{wmain}->refresh(@_);     }
sub _err  { $$app{wmain}->on_err_mess(@_); }
sub _inf  { $$app{wmain}->on_inf_mess(@_); }
sub _set_clipboard { $$app{wmain}->set_clipboard(@_); }

#--------------------- do mount/umount --------------------#

sub _do {
	my ($key,$dev,$name,$point,$type) = @_;
	my ($pe);
	_err('root'), return if $point && $point eq '/';

	my $mnt = _get_mount($dev);

	if ($mnt) {				# already mounted --> do umount
		if ($$conf{wrapper}) {
			if (my $cmd = $$conf{wrapper_mount}) {
				$point ||= $name || $dev;
				$point = join('/',$dir_media,$point) unless $point =~ m/^\//;
				($pe = $point) =~ s/\s/\\ /g;
				my $href = { dev => $dev, key => $key, name => $name,
						type => $type, point => $pe };
				$cmd =~ s/%(\w)/_macro($1,$href)/ge;
				_fork_n_run(split(' ',$cmd));
			}
		} else {
			($pe = $mnt) =~ s/\s/\\ /g;		# point escape
			_fork_n_run(@cmd_umount,$pe);
		}

	} else {				# not mounted --> do mount
		$point ||= $name || $dev;
		$point = join('/',$dir_media,$point) unless $point =~ m/^\//;
		($pe = $point) =~ s/\s/\\ /g;		# point escape

		if (-d $point) {	# exists mount point ?
			my ($d);		# mount point already mounted ?
			$d = _is_mount($point) and _err('already',$point,$d), return;
		} else {			# not exists mount point ?
							# try create mount point dir 
			eval { mkdir $pe or die; 1; };
			if ($@) {		# catch
				if ($$conf{sudo_for_mkdir}) {
					my @sudo = (@cmd_sudo, $$conf{sudo_askpass} ? '-A' : '-S');
					my $res = `@sudo @cmd_mkdir $pe 2>&1`;		#XXX
					_err('mkdir',$point,decode_utf8($res)), return if $res; 
				} else {
					_err('mkdir',$point,decode_utf8($!)), return; 
				}
			}
		}

		$_ = `$cmd_info $dev`;			#XXX
		$type = $1 if m/ID_FS_TYPE=(.+)/;

		my $opts = _get_opts($conf,$type);
		my @opts = $opts ? ('-o',$opts) : ();
		my $dpath = join('/',$dir_dev,$dev);

		if ($$conf{wrapper}) {
			if (my $cmd = $$conf{wrapper_mount}) {
				my $href = { dev => $dev, key => $key, name => $name,
						type => $type, point => $pe, opts => $opts };
				$cmd =~ s/%(\w)/_macro($1,$href)/ge;
				_fork_n_run(split(' ',$cmd));
			}
		} else {
			my $flag = 0;
			unless ($$conf{sudo_for_mount}) {
				my $fstab = _fstab();
				if (my $aref = $$fstab{$dev}) {
					my ($fstab_point) = @$aref;
					if ($fstab_point eq $point) {
						_fork_n_run(@cmd_mount,$pe);
						++$flag;
					}
				}
			}
			unless ($flag) {
				_fork_n_run(@cmd_mount,'-t',$type,@opts,$dpath,$pe);
			}
		}
		_set_clipboard($point) if $$conf{use_clipboard};
	}
	return 0;
}

sub _get_opts {
	my ($conf,$type) = @_;
	my $opts = $$conf{"fs_$type"};
	$opts =~ s/%u/$>/g;
	$opts =~ s/%g/(split(' ',$)))[0]/ge;
	return $opts;
}

sub _fork_n_run {
	my (@cmd) = @_;
	unshift(@cmd,(@cmd_sudo, $$conf{sudo_askpass} ?
				'-A' : '-S')) if $$conf{sudo_for_mount};

	warn "_FORK_N_RUN: '",join(' ',@cmd),"'.\n" if $debug;
	my ($pid,$fh);
	if ($pid = open($fh,'-|')) {	# fork:parent:read 
		Glib::IO->add_watch(fileno($fh),['in'],\&_callback,[$fh,$pid]);
		_note('work',1) unless %children;
		++$children{$pid};
	} else {						# child:write
		die "Can't fork: $!\n" unless defined $pid;
		$0 .= ' '.$cmd[0];
		$SIG{CHLD} = 'DEFAULT';
		$SIG{ALRM} = sub { exit 1 };
		alarm TIMEOUT;
		select STDOUT; $| = 1;		# autoflush
		print STDOUT `@cmd 2>&1`,"\n";		#XXX
		exit;
	}
}

sub _callback {
	#warn join("\n","ENGINE::_CALLBACK. ",@_,"\n");
	my (undef,undef,$tuple) = @_;
	my ($fh,$pid) = @$tuple;
	my (@lines);
	_rfsh();
	delete $children{$pid};
	_note('work',0) unless %children;
	@lines = <$fh>;
	return 0 unless @lines;
	warn "PARENT[$$]:READ: '",@lines,"'.\n" if $debug;
	foreach (@lines) {
		chomp;  s/^\s+//;  s/\s+$//;
		s/&/&amp;/g; s/</&lt;/g; s/>/&gt;/g;
	}
	return 0 unless $lines[0];

	if ($lines[0] =~ m/(umount.+device\sis\sbusy\.?)/) {
		_inf(_busy_with($1));
	} else {
		_inf(map decode_utf8($_),@lines);
	}
	return 0;		# STOP
}

sub _busy_with {
	my ($s) = @_;
	my ($mnt_point) = $s =~ m/^umount:?\s+(\S+?):?\s+device/;
	return $s unless $mnt_point;

	my (%seen,$k,$count);
	(($k) = split), ++$seen{$k} foreach `$cmd_lsof $mnt_point`;	#XXX
	delete $seen{COMMAND};
	return join(' ',_('Device'),$mnt_point,_('is busy with processes:')),
			map "   (".$seen{$_}.") $_", grep ++$count < 25,
				sort { $seen{$b} <=> $seen{$a} } keys %seen;
}

#-------------------- state & events ---------------------#

sub state_handler {
	my ($dat) = @_;
	our ($state);
	if ($state) {
		foreach my $dev (keys %$dat) {
			if (exists $$state{$dev}) {
				my $is_m_now = ${$$dat{$dev}}{is_m} ? 1 : 0;
				my $is_m_last = ${$$state{$dev}}{is_m} ? 1 : 0;
				next if $is_m_now == $is_m_last;
				_gen_event(($is_m_now ? 'mount' : 'umount'),$$dat{$dev});
			} else {
				_gen_event('catch',$$dat{$dev});
			}
		}
		foreach my $dev (keys %$state) {
			next if exists $$dat{$dev};
			_gen_event('loss',$$state{$dev});
		}
	}
	$state = $dat;
}

sub _gen_event {
	my ($tag,$href) = @_;
	$$conf{'on_'.$tag.'_run'} or return;
	my $cmd = $$conf{'on_'.$tag.'_command'} or return;
	$cmd =~ s/%(\w)/_macro($1,$href)/ge;
	warn "EVENT [$tag]: '$cmd'.\n" if $debug;
	_safe_exec(split(' ',$cmd));
}

sub _macro {
	my ($k,$href) = @_;
	return $> if $k eq 'u';
	return (split(' ',$)))[0] if $k eq 'g';
	return ($$href{opts} || _get_opts($conf,$$href{type})) if $k eq 'o';
	return '%' if $k eq '%';
	$k = $macro{$k} || '_';
	return exists($$href{$k}) ? $$href{$k} : '';
}

sub _safe_exec {
	my (@cmd) = @_;
	warn "_SAFE_EXEC: '",join(' ',@cmd),"'.\n" if $debug;
	unless (my $pid = fork) {		# fork:child:exec
		die "Can't fork: $!\n" unless defined $pid;
		exec(@cmd);		#XXX
	}
}

#------------------------ inotify ------------------------#

sub _inotify_start {
	my ($fh);
	return 0 unless $dir_block;	# STOP

	_inotify_stop();
	_rfsh();			# REFRESH
	_note('alert',1);

	if ($child_pid = open($fh,'-|')) {	# fork:parent:read 
		#warn "CHILD[$child_pid]:RUN.\n";
		Glib::IO->add_watch(fileno($fh),['in'], sub {
				my (undef,undef,$fh) = @_;
				1 while <$fh>;
				#chomp($_), warn "PARENT[$$]:READ: '$_'.\n" while <$fh>;
				Glib::Timeout->add(350,\&_inotify_start); # recursion
				return 0;			# STOP
			},$fh);
	} else {						# child:write
		die "Can't fork: $!\n" unless defined $child_pid;
		select STDOUT; $| = 1;		# autoflush
		exec(@cmd_notify,$dir_block);	#XXX
	}
	return 0;			# STOP
}

sub _inotify_stop { kill('INT',$child_pid) if $child_pid; }

#------------------------ get_data ------------------------#

## seen, include:
##   = have block device
##   = not have block device, but already mounted
##   = maybe, fuse recources from fstab (TODO?)
## exclude:
##   = not (have uuid || already mount || in fstab)
##   = swap

sub _disks {
	my (%hash,%seen,$dev,$count);
	my @fields = qw(name type size point hide);
	my $knowns = $$conf{_} || {};		# known disks from conf

	my $ids   = _devs($dir_id);
	my $uuids = _devs($dir_uuid);
	my $fstab = _fstab();
	my $sizes = _sizes();

	++$seen{$_} foreach _block_devs();		# have block devices
	++$seen{$_} foreach keys %$sizes;		# mounted devices

	while (($dev,$count) = each %seen) {		# dev
		next unless exists($$uuids{$dev}) || 
				exists($$sizes{$dev}) || exists($$fstab{$dev});
		my $key = $$uuids{$dev} || $$ids{$dev} || 
				(($$sizes{$dev} || $$fstab{$dev}) && join('/',$dir_dev,$dev)); 
		my $href = { dev => $dev, key => $key };

		if (my $fs = $$fstab{$dev}) {
			@$href{qw(point type)} = @$fs;		# TODO type = "udf,iso9660"|"auto"
		}
		next if $$href{type} && $$href{type} eq 'swap';
		if (my $known = $$knowns{$key}) {
			$$href{$_} = $$known{$_} foreach grep $$known{$_}, @fields;
		}
		if (my $rec = $$sizes{$dev}) {
			$$href{$_} = $$rec{$_} foreach keys %$rec;
			# set alarm marker if not have block device, but already mounted
			$$href{name} ||= '???' if $count < 2;
		}
		$hash{$dev} = $href;
	}
	return \%hash;			# dev => {...}
}

sub _sizes {
	my (%hash,$k,$v);
	my @fields = qw(type size used free pc point is_m);

	my @arr = `$cmd_df`;				#XXX
  L1:
	foreach (@arr) {
		$_ = decode_utf8($_);
		s/[\n\r]+$//;
		my ($d,$t,$s,$u,$f,$p,$m) = split(' ',$_,7);
		$d =~ m/\// or next; 
		while (-l $d) { $d = readlink $d or next L1; }	# go for links to device
		$d =~ s/^.*\/// or next; 
		@{$hash{$d}}{@fields} = ($t,$s,$u,$f,$p,$m,1);
	}
	return \%hash;			# dev => {field=>value,...}
}

sub _block_devs {
	my (@arr);
	return unless $dir_block;
	eval {
		opendir DIR,$dir_block or die;
		foreach (readdir DIR) {		# link
			my $dev = join('/',$dir_block,$_);
			next unless -l $dev;
			$dev = readlink $dev or next;
			$dev =~ s/^.*\///;
			push(@arr,$dev);
		}
		closedir DIR;
	1};
	warn if $@;
	return @arr;		# dev
}

sub _devs {
	my ($dir) = @_;
	my (%hash,$dev);
	eval {
		opendir DIR,$dir or die;
		foreach my $link (readdir DIR) {			# id|uuid
			$dev = $link = join('/',$dir,$link);	# full path
			next unless -l $dev;
			$dev = readlink $dev or next;
			$dev =~ s/^.*\///;		# dev only
			$hash{$dev} = $link;
		}
		closedir DIR;
	1};
	warn if $@;
	return \%hash;		# dev => id|uuid
}

sub _fstab {
	my (%hash);
	eval {
		open FSTAB,'<',$file_fstab or die;
	  LOOP:
		while (<FSTAB>) {
			chomp;  s/^\s+//;  s/\s+$//;  s/^#.*//;
			next unless length;
			my ($dev,$dir,$type,$opts) = split;
			$dev =~ s/UUID=/$dir_uuid\//;
					# go for links to device, if there have  
			while (-l $dev) {
				$dev = readlink $dev or next LOOP;
			}
			next unless $dev =~ s/^.*\///;		# dev only
			$hash{$dev} = [ $dir,$type,$opts ];
		}
		close FSTAB;
	1};
	warn if $@;
	return \%hash;		# dev => [point,type,opts]
}

sub _get_mount {
	my ($dev) = @_;
	my ($mnt);
	eval {
		open MTAB,'<',$file_mtab or die;
	  L2:
		while (<MTAB>) {
			my ($d,$m) = split(' ',$_,3);
			$d =~ m/\// or next;
			while (-l $d) { $d = readlink $d or next L2; }	# go for links to device
			$d =~ s/^.*\/// or next;
			$m =~ s/\\040/ /g;
			($mnt = $m) && last if $dev eq $d;
		}
		close MTAB;
	1};
	warn if $@;
	return $mnt;		# mnt ~ TRUE
}

sub _is_mount {
	my ($mnt) = @_;
	my ($dev);
	eval {
		open MTAB,'<',$file_mtab or die;
	  L3:
		while (<MTAB>) {
			my ($d,$m) = split(' ',$_,3);
			$d =~ m/\// or next;
			while (-l $d) { $d = readlink $d or next L3; }	# go for links to device
			$d =~ s/^.*\/// or next;
			$m =~ s/\\040/ /g;
			($dev = $d), last if $mnt eq $m;
		}
		close MTAB;
	1};
	warn if $@;
	return $dev;		# dev ~ TRUE
}

sub _ls_media {
	my (@arr);
	eval {
		opendir DIR,$dir_media or die;
		foreach (readdir DIR) {
			next if m/^\./;
			$_ = decode_utf8($_);
			next unless -d join('/',$dir_media,$_);
			push(@arr,$_);
		}
		closedir DIR;
	1};
	warn if $@;
	return [ sort @arr ];
}

1;
#--------------------------- end --------------------------#

