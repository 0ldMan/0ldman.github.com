package Hillman::Util;

use warnings;
use strict;
use utf8;
use Locale::gettext;
use Encode qw(decode_utf8);

use base 'Exporter';

our @EXPORT_OK = qw(sig_conn sig_emit _ _open _try_open);

### Simple event dispatching, mimic Gtk style.
### sig_conn(NAME, CODE, DATA)
### sig_emit(NAME, ARGS)

sub sig_conn {
    my ($self,$signal,$fun,@data) = @_;
    $self->{_sig}{$signal} ||= [];
    push @{$self->{_sig}{$signal}},[$fun,@data];
}

sub sig_emit {
	my ($self,$signal,@args) = @_;
	#warn "## emit $signal: @args (".ref($self).")\n";
	return unless exists $self->{_sig}{$signal};
	foreach my $aref (grep defined($_), @{$self->{_sig}{$signal}}) {
		my ($fun,@data) = @$aref;				# handler
		eval { $fun->($self,@args,@data) };		#<<<
		warn if $@;
	}
}

sub _ { return decode_utf8(gettext(shift)) }

sub _open {
					## Пытается открыть файл.
					## используется трехаргументная форма open
	my ($mode,$fullpath,@args) = @_;
	my ($fh);		## возвращает косвенный указатель файла (indirect filehandle)
					## или undef
					## NOTE: close не надо делать явно, оно сделается
					##       автоматически, как только на локальную $fh
					##       закончатся ссылки
	return $fh if open $fh,$mode,$fullpath,@args;
	return;
}

sub _try_open {
				## Открывает файл, создавая несуществующие каталоги пути.
				## используется трехаргументная форма open
	my ($mode,$fullpath,@args) = @_;
	my ($fh);	## возвращает косвенный указатель файла (indirect filehandle)
				## или undef
				## NOTE: close не надо делать явно, оно сделается 
				##       автоматически, как только на локальную $fh 
				##       закончатся ссылки

	return $fh if open $fh,$mode,$fullpath,@args;

	my (@arr);
	my $dir = $fullpath;
					# откусывать кусочки между слэшами от конца пути...
	while ($dir =~ s{/([^/]+)/?$}{}) {
		unshift @arr,$1;		#...и складывать их в массив
		last if -d $dir;		# этот каталог есть? закончить
	}
	pop @arr;		# выбросить имя файла, оставить только каталоги
	foreach (@arr) {
		$dir .= '/'.$_;			# удлиняя путь, 
		next if mkdir $dir;		# последовательно создавать каталоги

		warn "Can't mk_dir: $dir: $!\n";
		return;
	}
	if (! -f $fullpath and $mode eq '+<') {		# если файла нет...
		open TMP,'>>',$fullpath;		#...создать его, нулевой длины 
		close TMP;
	}
					# второй раз попытаться открыть файл
	return $fh if open $fh,$mode,$fullpath,@args;

	warn "Can't open file $fullpath: $!\n";
	return;
}


1;
#--------------------------- end --------------------------#

