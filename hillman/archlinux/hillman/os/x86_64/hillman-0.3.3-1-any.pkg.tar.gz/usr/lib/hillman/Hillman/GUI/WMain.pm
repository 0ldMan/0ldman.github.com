package Hillman::GUI::WMain;

use warnings;
use strict;
use Gtk2;
use Gtk2::TrayIcon;

use Hillman::Util qw(_);

use base 'Gtk2::Window';

use constant { C_ACT=>0,C_ISM=>1,C_NAME=>2,C_DEV=>3,C_TYPE=>4,
	C_SIZE=>5,C_USED=>6,C_FREE=>7,C_PC=>8,C_POINT=>9,C_KEY=>10 };	# column number

use constant { BLINK_DELAY=>200,INFO_DELAY=>13000,MAX_POOL=>31 };

my ($app,$conf,$ui,$tips,%errfmt);

my $ui_def = q{
<ui>
	<menubar name='MenuBar'>
		<menu action='FileMenu'>
            <menuitem action='Quit'/>
		</menu>
		<menu action='ViewMenu'>
            <menuitem action='Refresh'/>
            <menuitem action='ViewHidden'/>
            <separator/>
            <menuitem action='Prefs'/>
		</menu>
		<menu action='HelpMenu'>
            <menuitem action='About'/>
		</menu>
	</menubar>
	<toolbar name='ToolBar'>
		<placeholder name='Opts'>
			<toolitem action='Refresh'/>
            <separator/>
			<toolitem action='Prefs'/>
		</placeholder>
	</toolbar>
	<accelerator action='CopyAccel'/>
</ui>
};

sub _init_entries {
	%errfmt = (
		'mkdir' 	=> _('Can not create mount point directory:')."\n\"%s\".\n%s.",
		'already'	=> _('In directory')." %s\n".
							_('already mounted device')." \" %s\".",
		'root'  	=> _('You attempt umount root filesystem.'),
	);
	return [
				#--- entries ---#
		[ 'FileMenu',		undef, _('_File') ],
		[ 'ViewMenu',		undef, _('_View') ],
		[ 'HelpMenu',		undef, _('_Help') ],
		[ 'CopyAccel',		undef,'','<control>C','',\&_copy_accel ],
		[ 'Quit','gtk-quit',_('_Quit'),'<control>Q',
				_('Quit this program'), sub { Hillman::quit() } ],
		[ 'Refresh','gtk-refresh',_('_Refresh'),'<control>R',
				_('Refresh'),\&_refresh ],
		[ 'Prefs','gtk-preferences',_('_Preferences...'),undef,
				_('Show application preferences'),\&_show_app_pref ],
		[ 'About','gtk-about',_('_About...'),undef,
				_('About this program'),\&_about ],
	],[
				#--- entries_toggle ---#
		[ 'ViewHidden','gtk-connect',_('_View Hidden Disks'),undef,
				_('View Hidden Partitions'),\&_toggle_view_hidden,1 ],
		[ 'StartInTray','gtk-connect',_('Start in _Tray'),undef,
				_('Application in tray on start '),\&_toggle_start_in_tray,1 ],
	];
}

sub new {
	my ($class,$_app) = @_;
	$app = $_app;
	$conf = $$app{conf};
	my $self = bless Gtk2::Window->new('toplevel'),$class;
	$self->set_title($Hillman::NAME);
	$self->set_icon_from_file($Hillman::ICON);
	$self->set_default_size(500,350);
	#$self->signal_connect('delete_event', sub { Hillman::quit() });
	$self->signal_connect('delete_event', sub {
			($self->{pos_x},$self->{pos_y}) = $self->get_position();
			$self->hide(); 1; 
		});
	$self->signal_connect('show',\&_refresh,$self);
	#$self->signal_connect('show', sub { $self->_tray_set('alert',0) });
	Glib::Timeout->add(1300, sub { $self->_tray_set('alert',0); 0});	#STOP

	my ($traymenu,$pool) = _tray_menu($self);

	my $pixdir = $Hillman::PIXDIR;
	my $pixhom = $ENV{HOME}.'/.hillman/pixmaps';
	my %trayicons = map {
			my ($tag,$x) = ($_);
			eval { $x = Gtk2::Gdk::Pixbuf->new_from_file("$pixhom/$tag.png"); 1};
			eval { $x = Gtk2::Gdk::Pixbuf->new_from_file("$pixdir/$tag.png"); 1} unless $x;
			$x = Gtk2::Gdk::Pixbuf->new_from_xpm_data('1 1 1 1','+ c none','+') unless $x;
			$tag => $x;
		} qw(normal alert work);
			
	my $trayimage = Gtk2::Image->new_from_pixbuf($trayicons{normal});

	my $tooltips = Gtk2::Tooltips->new();
	my $tray = Gtk2::TrayIcon->new('hillman');
	my $eventbox = Gtk2::EventBox->new();
	$eventbox->signal_connect('button-press-event',\&_on_tray_click,[$self,$traymenu]);
	$eventbox->signal_connect('leave-notify-event', 
		sub { Glib::Idle->add(sub { $self->_tray_set('alert',0); 0}); });	#STOP
	$eventbox->add($trayimage);
	$tooltips->set_tip($eventbox,'Hillman');
	$tray->add($eventbox);
	$tray->show_all();
	_gui_update();

	my ($entries,$entries_toggle) = _init_entries();

	my $ag = Gtk2::ActionGroup->new('Actions');
	$ag->add_actions($entries,$self);
	$ag->add_toggle_actions($entries_toggle,$self);

	$ui = Gtk2::UIManager->new();
	$ui->insert_action_group($ag,0);
	$ui->add_ui_from_string($ui_def);
	$self->add_accel_group($ui->get_accel_group());

	my $menubar = $ui->get_widget('/MenuBar'); 
	my $a_hide = $ui->get_action('/MenuBar/ViewMenu/ViewHidden');
	$a_hide->set_active($$conf{view_hidden} ? 1 : 0);

	my $box = Gtk2::VBox->new(0,0);

	my $sw = Gtk2::ScrolledWindow->new();
	$sw->set_shadow_type('in');
	$sw->set_policy('automatic','automatic');
	$sw->set_size_request(100,100);
	
	my ($store,$tv) = _grid($self);
	$sw->add($tv);

	$box->pack_start($menubar,0,0,0);
	$box->pack_start($sw,1,1,0);
	$self->add($box);

	$box->show_all();
	$self->realize();
	$self->show() unless $$conf{start_in_tray};
	($self->{pos_x},$self->{pos_y}) = $self->get_position();
	$self->{pool} = $pool;
	$self->{store} = $store;
	$self->{tv} = $tv;
	$self->{trayicons} = \%trayicons;
	$self->{trayimage} = $trayimage;
	$self->{fn_tip} = sub { $tooltips->set_tip($eventbox,shift) };
	$app->{wmain} = $self;
	return $self;
}

sub _tray_menu {
	my ($self) = @_;
	my (@pool);
	my $menu = Gtk2::Menu->new();
	my $pref = Gtk2::ImageMenuItem->new_from_stock('gtk-preferences');
	my $quit = Gtk2::ImageMenuItem->new_from_stock('gtk-quit');
	$pref->signal_connect('activate', \&_show_app_pref);
	$quit->signal_connect('activate', sub { Hillman::quit() });

	foreach (0..MAX_POOL) {
		my $item = Gtk2::CheckMenuItem->new($_); 
		$item->signal_connect('toggled',\&_toggled_menu_handler,$self);
		$menu->append($item);
		push(@pool,$item);
	}
	$menu->append(Gtk2::SeparatorMenuItem->new());
	$menu->append($pref);
	$menu->append(Gtk2::SeparatorMenuItem->new());
	$menu->append($quit);
	$menu->show_all();
	$_->hide() foreach @pool;
	return $menu,\@pool;
}

sub _tray_set {
	#warn join("\n","WMAIN::_TRAY_SET. ",@_,"\n");
	my ($self,$tag,$value) = @_;
	my $flags = $self->{trayflags} ||= {};
	return unless $$flags{$tag} xor $value;

	my $blink = ($tag eq 'work') && !$$flags{work} && $value;
	$$flags{$tag} = $value;

	$tag = $$flags{work} ? 'work' : $$flags{alert} ? 'alert' : 'normal';
	my $icons = $self->{trayicons};
	my $image = $self->{trayimage};
	$image->set_from_pixbuf($$icons{$tag});

	if ($blink) {
		_gui_update();
		my $iter_by_key = $self->{iter_by_key} || {};
		my $store = $self->{store};			# grid
		my $key = $self->{blink_key};
		my $en = $store && $key ? 1 : 0;
		my $on = 1;

		if ($en && $self->visible) {
			my $iter = $$iter_by_key{$key};		# grid row
			$store->set($iter,C_ACT,'gtk-media-record') if $iter;
		}

		Glib::Timeout->add(BLINK_DELAY, sub {
				if ($$flags{work}) {
					$on = !$on;
					$image->set_from_pixbuf($$icons{$on ? 'work' : 'normal'});
					if ($en && $self->visible) {
						my $iter = $$iter_by_key{$key};		# grid row
						$store->set($iter,C_ACT,($on ? 'gtk-media-record' : '')) if $iter;
					}
					return 1;	#CONTINUE
				} else {		
					$image->set_from_pixbuf($$icons{normal}); 
					if ($en) {
						my $iter = $$iter_by_key{$key};		# grid row
						$store->set($iter,C_ACT,'') if $iter;
						$self->{blink_key} = '';
					}
					return 0;	#STOP
				}
			});
	}
	return 1;
}

#------------------------- method -------------------------#

sub note { 
	my (undef,@arr) = @_;
	Glib::Idle->add(sub { _tray_set($app->{wmain},@arr); 0});	#STOP
}

sub refresh { 
	Glib::Idle->add(sub { _refresh(0,$app->{wmain}); 0});	#STOP
}

sub on_err_mess {
	#warn join("\n","WMAIN::ON_ERR_MESS. ",@_,"\n");
	my ($self,$tag,@arr) = @_;

	my $dialog = Gtk2::MessageDialog->new_with_markup (
			$self,[qw(modal destroy-with-parent)],
			'error','close',sprintf($errfmt{$tag},@arr));

	$dialog->set_title(join(' ',$Hillman::NAME,'Error'));
	$dialog->run();
	$dialog->destroy();
	return 1;
}

sub on_inf_mess {
	#warn join("\n","WMAIN::ON_INF_MESS. ",@_,"\n");
	my ($self,@arr) = @_;

	my $dialog = Gtk2::MessageDialog->new_with_markup (
			$self,[qw(modal destroy-with-parent)],
			'info','close',join("\n",@arr));

	Glib::Timeout->add(INFO_DELAY, sub { $dialog && $dialog->destroy(); 0});	#STOP

	$dialog->set_title(join(' ',$Hillman::NAME,'Info'));
	$dialog->run();
	$dialog->destroy();
	return 1;
}

sub set_clipboard {
	#warn join("\n","WMAIN::SET_CLIPBOARD. ",@_,"\n");
	my (undef,$point) = @_;
	my $cb = Gtk2::Clipboard->get(Gtk2::Gdk::Atom->intern('PRIMARY'));
	$point =~ s/\s/\\ /g;		# point escape
	$cb->set_text($point);
	return 1;
}

#------------------------- handler ------------------------#

sub _refresh {
	#warn join("\n","WMAIN::_REFRESH. ",@_,"\n");
	my (undef,$self) = @_;
	our $no_first_rfsh;
	return 1 unless $self->visible || !($no_first_rfsh ||= $no_first_rfsh++);

	my (@tips);
	my @fields = qw(is_m name key type size used free pc point hide);
	my $view_hidden = $$conf{view_hidden};
	my $dat = Hillman::Engine::get_data();
	my $store = $self->{store} or return;	# grid
	my $pool = $self->{pool} or return;		# tray menu
	my $iter_by_key = $self->{iter_by_key} ||= {};
	my $i = 0;
	$store->clear();
	$_->hide() foreach @$pool;
	$self->{flag_refresh} = 1;

	foreach my $dev (sort keys %$dat) {
					# get data
		my $href = $$dat{$dev};
		my ($is_m,$name,$key,$type,
				$size,$used,$free,$pc,$point,$hide) = @$href{@fields};
		next unless $key;
		next if $hide && !$view_hidden;
					# grid row
		my $act = $name && $name eq '???' ? 
				'gtk-dialog-warning' : $hide ? 'gtk-zoom-fit' : '';
		my $iter = $store->append();
		$store->set($iter,C_ACT,$act,C_ISM,$is_m,C_NAME,$name,C_DEV,$dev,
				C_TYPE,$type,C_SIZE,$size,C_USED,$used,C_FREE,$free,C_PC,$pc,
				C_POINT,$point,C_KEY,$key);
		$$iter_by_key{$key} = $iter;
					# tray tooltip
		push(@tips,' '.join('  ',($name || $dev),$size,$pc,$point).' ') if $is_m;
					# tray menu item
		my $item = $$pool[$i++] or next;
		$item->{___st_iter} = $iter;
		$item->child->set_text($name || $dev || $point);
		$item->set_active($is_m ? 1 : 0);
		$item->show();
	}
	$self->{flag_refresh} = 0;
	@tips = ('Hillman') unless @tips;

	Glib::Idle->add(sub { Hillman::Engine::state_handler($dat); 0});	#STOP
	Glib::Idle->add(sub { &{$self->{fn_tip}}(join("\n",@tips)); 0});	#STOP
	return 1;
}

sub _on_tray_click {
	#warn "WMAIN::_ON_TRAY_CLICK. ",@_,"\n";
	my ($eventbox,$event,$data) = @_;
	my ($self,$menu) = @$data;

	my $n = $event->button;
	if ($n == 1) {
		if ($self->visible) {
			($self->{pos_x},$self->{pos_y}) = $self->get_position();
			$self->hide();
		} else {
			$self->move($self->{pos_x},$self->{pos_y}) if $self->{pos_x} || $self->{pos_y};
			$self->show();
			$self->present();
		}
		Glib::Idle->add(sub { $self->_tray_set('alert',0); 0});	#STOP
	} elsif ($n == 3) {
		$menu->popup(undef,undef,\&_position_menu,
				[$self,$eventbox,$event],$n,$event->time);
		Glib::Idle->add(sub { $self->_tray_set('alert',0); 0});	#STOP
	}
	return 1;
}

sub _toggle_view_hidden {
	#warn "_TOGGLE_VIEW_HIDDEN. ",@_,"\n";
	my ($action,$self) = @_;
	$$conf{view_hidden} = $action->get_active() ? 1 : 0;
	Glib::Idle->add(sub { _refresh(0,$self); 0});	#STOP
	return 1;
}

sub _toggle_start_in_tray {
	#warn "_TOGGLE_START_IN_TRAY. ",@_,"\n";
	my ($action,$self) = @_;
	$$conf{start_in_tray} = $action->get_active() ? 1 : 0;
	Glib::Idle->add(sub { _refresh(0,$self); 0});	#STOP
	return 1;
}

sub _show_app_pref { $$app{wpref}->show(); 1; }

sub _about {
	my $logo = Gtk2::Gdk::Pixbuf->new_from_file($Hillman::LOGO);
	my %info = (
		'program-name'	=> $Hillman::NAME,
		'version'		=> $Hillman::VERSION,
		'authors'		=> $Hillman::AUTHOR,
		'comments'		=> _('Mount Manager'),
		'website'		=> $Hillman::URL,
		'logo'  		=> $logo,
	);
	if (Gtk2->CHECK_VERSION(2,6,0)) {
		Gtk2->show_about_dialog(undef,%info);
	}
	return 1;
}

#-------------------------- grid --------------------------#

sub _grid {
	my ($self) = @_;
	my ($cell,$col);
	my @order = qw(name dev type size used free pc point);
	my $store = Gtk2::ListStore->new('Glib::String','Glib::Boolean',
			(map 'Glib::String',@order),'Glib::String');
	$store->set_sort_column_id(3,'ascending');

	my $tv = Gtk2::TreeView->new($store);
	$tv->set_headers_visible(1);
	$tv->set_rules_hint(1);

	my $tuple = _popup_menu($store,$tv);
	$tv->signal_connect('button-press-event',\&_on_button_press,$tuple);
	$tv->signal_connect('row_activated',\&_activated_handler,$self);

	my $tsel = $tv->get_selection();
	$tsel->set_mode('single');		# none,single,browse,multiple,extended
	$tsel->signal_connect('changed', sub { $self->_tray_set('alert',0) });
				#--- Active
	$cell = Gtk2::CellRendererPixbuf->new();
	$col = Gtk2::TreeViewColumn->new_with_attributes('a',$cell,'stock_id',C_ACT);
	$col->set_min_width(20);		# место для маркера
	$tv->append_column($col);
				#--- Enable
	$cell = Gtk2::CellRendererToggle->new();
	$cell->signal_connect('toggled',\&_toggled_handler,$self);
	$col = Gtk2::TreeViewColumn->new_with_attributes('ism',$cell,'active',C_ISM);
	$tv->append_column($col);

	foreach my $i (0..$#order) {
		$cell = Gtk2::CellRendererText->new();
		$col = Gtk2::TreeViewColumn->new_with_attributes($order[$i],$cell,'text',($i + 2));
		$col->set_sizing('autosize');
		$tv->append_column($col);
	}
				#--- UUID
	$cell = Gtk2::CellRendererText->new();
	$col = Gtk2::TreeViewColumn->new_with_attributes('key',$cell,'text',C_KEY);
	$col->set_visible(0);			# hide column
	$tv->append_column($col);
	return $store,$tv;
}

sub _popup_menu {
	my ($store,$tv) = @_;
	my $menu = Gtk2::Menu->new();

	my $mnt = Gtk2::ImageMenuItem->new(_('_Mount'));
	my $umnt = Gtk2::ImageMenuItem->new(_('_Umount'));
	my $copy = Gtk2::ImageMenuItem->new(_('Copy').(' 'x 8).'Ctrl+_C');
	my $prop = Gtk2::ImageMenuItem->new_from_stock('gtk-properties');

	my $tuple = [$store,$tv];
	$mnt->signal_connect('activate',\&_mnt_handler,$tuple);
	$umnt->signal_connect('activate',\&_umnt_handler,$tuple);
	$copy->signal_connect('activate',\&_copy_handler,$tuple);
	$prop->signal_connect('activate',\&_prop_handler,$tuple);

	$menu->append($mnt);
	$menu->append($umnt);
	$menu->append(Gtk2::SeparatorMenuItem->new());
	$menu->append($copy);
	$menu->append(Gtk2::SeparatorMenuItem->new());
	$menu->append($prop);
	$menu->show_all();
	return [ $menu,$mnt,$umnt ];
}

sub _on_button_press {
	#warn join("\n","WMAIN::BUTTON-PRESS-EVENT. ",@_,"\n");
	my ($tv,$event,$tuple) = @_;
	my $n = $event->button;
	return 0 unless $n == 3;

	my ($menu,$mnt,$umnt) = @$tuple;
	Glib::Idle->add(sub {
			my @rows = $tv->get_selection->get_selected_rows();
			my $store = $tv->get_model();
			foreach (reverse @rows) {
				my $iter = $store->get_iter($_);
				my ($is_m,$dev,$point) = $store->get($iter,C_ISM,C_DEV,C_POINT);
				#warn "   ITER[$iter]: $dev ($is_m) --> $point.\n";
				if ($is_m) {
					$mnt->set_sensitive(0);
					$umnt->set_sensitive(1);
				} else {
					$mnt->set_sensitive(1);
					$umnt->set_sensitive(0);
				}
				$menu->popup(undef,undef,undef,undef,$n,0);
				last;
			}
			0});	#STOP
	return 0; 
}

sub _mnt_handler {
	#warn join("\n","WMAIN::_MNT_HANDLER. ",@_,"\n");
	my (undef,$tuple) = @_;
	my ($store,$tv) = @$tuple;
	my @rows = $tv->get_selection->get_selected_rows();
	foreach (reverse @rows) {
		my $iter = $store->get_iter($_);
		my ($is_m,$key,$dev,$name,$point,$type) = 
				$store->get($iter,C_ISM,C_KEY,C_DEV,C_NAME,C_POINT,C_TYPE);
		last if $is_m;
		Hillman::Engine::do($key,$dev,$name,$point,$type);
		last;
	}
}

sub _umnt_handler {
	#warn join("\n","WMAIN::_UMNT_HANDLER. ",@_,"\n");
	my (undef,$tuple) = @_;
	my ($store,$tv) = @$tuple;
	my @rows = $tv->get_selection->get_selected_rows();
	foreach (reverse @rows) {
		my $iter = $store->get_iter($_);
		my ($is_m,$key,$dev,$name,$point,$type) = 
				$store->get($iter,C_ISM,C_KEY,C_DEV,C_NAME,C_POINT,C_TYPE);
		last unless $is_m;
		Hillman::Engine::do($key,$dev,$name,$point,$type);
		last;
	}
}

sub _copy_accel {
	my (undef,$self) = @_;
	_copy_handler(undef,[$self->{store},$self->{tv}]);
}

sub _copy_handler {
	#warn join("\n","WMAIN::_COPY_HANDLER. ",@_,"\n");
	my (undef,$tuple) = @_;
	my ($store,$tv) = @$tuple;
	my @rows = $tv->get_selection->get_selected_rows();
	foreach (reverse @rows) {
		my $iter = $store->get_iter($_);
		my ($point) = $store->get($iter,C_POINT);
		last unless $point;
		set_clipboard(undef,$point);
		last;
	}
}

sub _prop_handler {
	#warn join("\n","WMAIN::_PROP_HANDLER. ",@_,"\n");
	my (undef,$tuple) = @_;
	my ($store,$tv) = @$tuple;
	my @rows = $tv->get_selection->get_selected_rows();
	foreach (reverse @rows) {
		my $iter = $store->get_iter($_);
		my ($key,$dev,$name,$point,$type) = 
				$store->get($iter,C_KEY,C_DEV,C_NAME,C_POINT,C_TYPE);
		$$app{wpref}->show_item_prop($key,$dev,$name,$point,$type); 
		last;
	}
}

sub _activated_handler {
	#warn "_ACTIVATED_HANDLER. ",@_,"\n";
	my ($tv,$path,$column,$self) = @_;
	my $store = $tv->get_model();
	my $iter = $store->get_iter($path);
	my ($key,$dev,$name,$point,$type) = 
			$store->get($iter,C_KEY,C_DEV,C_NAME,C_POINT,C_TYPE);
	$$app{wpref}->show_item_prop($key,$dev,$name,$point,$type); 
}

sub _toggled_handler {
	#warn "_TOGGLED_HANDLER. ",@_,"\n";
	my ($cell,$path,$self) = @_;
	my $store = $self->{store} or return;
	my $tp = Gtk2::TreePath->new_from_string($path);
	my $iter = $store->get_iter($tp);
	my ($key,$dev,$name,$point,$type) = 
			$store->get($iter,C_KEY,C_DEV,C_NAME,C_POINT,C_TYPE);
	$self->{blink_key} = $key;
	Hillman::Engine::do($key,$dev,$name,$point,$type);
}

sub _toggled_menu_handler {
	my ($item,$self) = @_;
	return if $self->{flag_refresh};
	my $store = $self->{store} or return;
	my $iter = $item->{___st_iter} or return;
	my ($key,$dev,$name,$point,$type) = 
			$store->get($iter,C_KEY,C_DEV,C_NAME,C_POINT,C_TYPE);
	$self->{blink_key} = $key;
	Hillman::Engine::do($key,$dev,$name,$point,$type);
}

#--------------------------- sub --------------------------#

sub _gui_update { Gtk2->main_iteration while Gtk2->events_pending }

sub _position_menu {
	my ($menu,undef,undef,$data) = @_;
	my ($self,$eventbox,$event) = @$data;

    my $x = $event->x_root - $event->x;
    my $y = $event->y_root - $event->y;

	my $monitor = $menu->get_screen->get_monitor_at_point($x,$y);
	my $rect = $menu->get_screen->get_monitor_geometry($monitor);
	my $siz = $menu->size_request();
	my $sp_above = $y - $rect->y;
	my $sp_below = $rect->y + $rect->height - $y;

	if (($siz->height <= $sp_above) || ($siz->height <= $sp_below)) {
		$y = $siz->height <= $sp_below ? 
				$y + $eventbox->allocation->height : $y - $siz->height;
	
	} elsif (($siz->height > $sp_below) && ($siz->height > $sp_above)) {
		$y = $sp_below >= $sp_above ? 
				$rect->y + $rect->height - $siz->height : $rect->y;

	} else {
		$y = $rect->y;
	}
	return $x,$y,1;
}

1;
#--------------------------- end --------------------------#

